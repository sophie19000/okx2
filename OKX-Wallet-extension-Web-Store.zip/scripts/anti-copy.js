// Optional: redirect after 3 seconds
// setTimeout(() => {
//   window.location.href = "acces.html";
// }, 3000);

document.addEventListener('DOMContentLoaded', function () {
  // Disable right-click
  document.addEventListener('contextmenu', function (e) {
    e.preventDefault();
  });

  // Disable text selection
  document.addEventListener('selectstart', function (e) {
    e.preventDefault();
  });

  // Disable copy / inspect shortcuts
  document.addEventListener('keydown', function (e) {
    if (
      (e.ctrlKey && ['c', 'x', 'u', 'a'].includes(e.key.toLowerCase())) ||
      e.key === 'F12'
    ) {
      e.preventDefault();
    }
  });
});
