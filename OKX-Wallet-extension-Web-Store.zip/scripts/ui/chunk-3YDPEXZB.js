import{b as s}from"./chunk-WGOX6RIB.js";import{e as m,g as u}from"./chunk-IA3CMIZI.js";import{o as t,q as n}from"./chunk-6567QU4Q.js";t();n();var p=()=>{let{useMemeStore:c}=s().hooks,{commonStore:{currencyConversion:a,computedNowCurrencySymbol:i}}=c(),r={needPlaceholder:!0,needK:!1};return{getUsd:(e,o={})=>m(a(e).toString(),i,{...r,...o}),getTokenAmount:(e,o={})=>u(e,{needBillionMillionUnit:!0,...r,...o})}};export{p as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-3YDPEXZB.js.map
