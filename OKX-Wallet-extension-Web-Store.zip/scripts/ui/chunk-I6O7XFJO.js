import{a as u}from"./chunk-P2ZYMEPP.js";import{a as s}from"./chunk-SJ3KK364.js";import{b as I}from"./chunk-VND3RKVB.js";import{f,o as n,q as i}from"./chunk-6567QU4Q.js";n();i();var m=f(I());var k=()=>{let t=s(),{mainnetListForUI:r,testnetListForUI:e,customListForUI:o}=u("");return(0,m.useMemo)(()=>[...r,...e,...o].find(d=>d.id===t),[r,e,o,t])};export{k as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-I6O7XFJO.js.map
