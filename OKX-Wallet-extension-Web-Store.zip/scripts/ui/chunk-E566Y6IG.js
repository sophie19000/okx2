import{o as E,q as T}from"./chunk-6567QU4Q.js";E();T();var C={IMPORT:"IMPORT",VERIFY:"VERIFY",NO_ACTION:"NO_ACTION",RECOVER:"RECOVER"},e="/account/users",A={NORMAL:0,DELETE:1,FROZEN:2},R={INIT:0,WALLETCREATED:1,BACKUPED:2,RECOVER:3,ESCAPE:4,BACKUPED_FAIL:5};export{C as a,e as b,A as c,R as d};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-E566Y6IG.js.map
