import{Fb as u,ic as d}from"./chunk-SJNNRA35.js";import{Ad as a,ad as n,dd as s}from"./chunk-BY6GMUSF.js";import{f as A,o,q as l}from"./chunk-6567QU4Q.js";o();l();var r=A(d());a();var c=()=>(0,r.useSelector)(u)?.account||{},I=e=>{let t=c();return e?t[e]||"":t},S=(e=n)=>c()[e]||"";var f=()=>c()[s];export{I as a,S as b,f as c};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-7XLH3J55.js.map
