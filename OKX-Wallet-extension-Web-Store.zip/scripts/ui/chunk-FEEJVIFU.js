import{$c as f,Cd as c,Fd as _,Id as u,oc as a}from"./chunk-BY6GMUSF.js";import{o as l,q as p}from"./chunk-6567QU4Q.js";l();p();f();u();var m=(t,i,d)=>{let{symbol:o,localType:r}=d||{},e=t("wallet_extension_popup_title_receiving_address_copied");if(!i||!o)return e;let n=_?.[r]?.[i];if(!n||r===a)return e;let s=c[n];return s&&(e=t("extension_wallet_transaction_notif_address_copied1",{address:t(s),chainName:o})),e},T=m;export{T as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-FEEJVIFU.js.map
