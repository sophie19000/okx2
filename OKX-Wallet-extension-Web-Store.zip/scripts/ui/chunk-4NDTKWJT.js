import{da as r}from"./chunk-2VNSL6BU.js";import{A as e,n as s}from"./chunk-CKMW3O5Z.js";import{o as t,q as o}from"./chunk-6567QU4Q.js";t();o();e.init({project:r});e.session.init({project:r});var S=s()?e:e.getInstance(r),m=s()?e.session:e.session.getInstance(r);t();o();function i(){if(s())return!1;try{return window.self!==window.top}catch{return!1}}export{S as a,m as b,i as c};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-4NDTKWJT.js.map
