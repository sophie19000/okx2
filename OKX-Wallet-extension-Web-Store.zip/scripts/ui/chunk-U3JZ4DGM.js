import{a as r}from"./chunk-2DFYYD5Z.js";import{f as p,o as t,q as c}from"./chunk-6567QU4Q.js";t();c();var o=p(r());async function i(a=""){try{await(0,o.default)(a)}catch{}}export{i as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-U3JZ4DGM.js.map
