import{e}from"./chunk-F5L2TBXZ.js";import{o as r,q as o}from"./chunk-6567QU4Q.js";r();o();var s=e;r();o();var i=(t="")=>{let n=t.substring(0,10);return t.length>10?`${n}...`:t};export{i as a,s as b};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-R2VT47TY.js.map
