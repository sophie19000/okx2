import{a as o,b as l,c as a,d as h,e as f,f as u,g,h as C}from"./chunk-53BD3ML4.js";import{o as i,q as r}from"./chunk-6567QU4Q.js";i();r();var x=(n,s)=>{let t="";if(u(n))t=s.signature;else if(l(n)){let{transaction:e}=s;t=e?.txID}else if(g(n))t=s;else if(a(n))t=s;else if(h(n))t=s.txHash;else if(f(n))t=s.transaction_hash;else if(o(n))t=s;else if(C(n))t=s.txHash;else{let{hash:e,nonce:c}=s;return{result:e,nonce:c}}return{result:t}},S=x;export{S as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-THCDDBR3.js.map
