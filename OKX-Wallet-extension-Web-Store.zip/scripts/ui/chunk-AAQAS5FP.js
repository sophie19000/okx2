import{a as g}from"./chunk-RKBUK4AS.js";import{a as u}from"./chunk-GPUFECCR.js";import{b as c}from"./chunk-VND3RKVB.js";import{f as l,o as t,q as e}from"./chunk-6567QU4Q.js";t();e();var o=l(c()),r=l(g()),p=l(u());t();e();var m={"wallet-link":"_wallet-link_fxfbg_1",walletLink:"_wallet-link_fxfbg_1"};var x=({to:n,href:a,style:f,target:i,children:s,className:k,replace:_=!1})=>o.default.createElement(n?r.Link:"a",{to:n,href:a,style:f,target:i||(a?"_blank":"_self"),className:(0,p.default)(m["wallet-link"],k),replace:_},s),h=o.default.memo(x);export{h as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-AAQAS5FP.js.map
