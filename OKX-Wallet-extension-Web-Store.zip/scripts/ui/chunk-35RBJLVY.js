import{Ja as m,La as x,Xa as a}from"./chunk-BY6GMUSF.js";import{f,o as t,q as e}from"./chunk-6567QU4Q.js";t();e();t();e();var o=f(m());a();var d=async n=>{try{let{TrxWallet:s}=await x(),r=s.toHexAddress(n);return r.indexOf("41")===0&&r.length===42?(0,o.addHexPrefix)(r.substring(2)):(0,o.addHexPrefix)(r)}catch{}return""};export{d as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-35RBJLVY.js.map
