import{j as s}from"./chunk-3P7JMI3F.js";import{X as n,ic as x,zb as a}from"./chunk-SJNNRA35.js";import{$d as d,Ld as o}from"./chunk-BY6GMUSF.js";import{f as p,o as e,q as r}from"./chunk-6567QU4Q.js";e();r();var l=p(x());d();var b=()=>{let t=(0,l.useSelector)(a),c=s(t);return async i=>{let u=c?.serverWalletType,m={txSource:o.NORMAL,accountId:t,walletType:u,...i};return await n(m,{walletSignParams:{needWalletSign:!0,walletId:t}})}};export{b as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-S4XPQDJK.js.map
