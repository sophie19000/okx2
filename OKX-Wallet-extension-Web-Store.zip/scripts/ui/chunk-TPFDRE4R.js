import{c as a}from"./chunk-SJNNRA35.js";import{f as u,o as l,q as r}from"./chunk-6567QU4Q.js";l();r();var t=u(a()),n=(e,o)=>typeof e=="object"&&e!==null&&typeof o=="object"&&o!==null?Object.keys(e).every(c=>e[c]===o[c]):e===o,f=(0,t.createSelectorCreator)(t.defaultMemoize,n);export{f as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-TPFDRE4R.js.map
