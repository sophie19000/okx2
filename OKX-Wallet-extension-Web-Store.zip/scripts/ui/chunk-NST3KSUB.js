import{k as o,l as p}from"./chunk-PNQHXYIW.js";import{o as s,q as r}from"./chunk-6567QU4Q.js";s();r();p();var a=o({name:"approve",initialState:{approvedList:[],hasFetchedData:!1},reducers:{setApprovedList:(e,t)=>{e.approvedList=t.payload},setHasFetchedData:(e,t)=>{e.hasFetchedData=t.payload}}}),{actions:c,reducer:d}=a,h=d,l=e=>e[a.name].approvedList,v=e=>e[a.name].hasFetchedData,{setApprovedList:D,setHasFetchedData:F}=c;export{h as a,l as b,v as c,D as d,F as e};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-NST3KSUB.js.map
