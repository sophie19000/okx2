import{b as a}from"./chunk-OX2V4RV7.js";import{a as g}from"./chunk-4WCXSYVQ.js";import{E as p}from"./chunk-ZBTXKGF6.js";import{Ad as S,Ja as E,Va as I,Wa as s,Xa as N,rd as m,td as f}from"./chunk-BY6GMUSF.js";import{c as h,i as u,ra as l}from"./chunk-2A3K6ORU.js";import{f as k,o as d,q as T}from"./chunk-6567QU4Q.js";d();T();var r=k(E());l();N();S();var W=async o=>{let{Common:t,Hardfork:e}=await I();(0,r.isHexString)(u(o.chainId))&&(o.chainId=h(g(o.chainId)));let n=m({netWorkId:o.chainId})?.baseChain,i=()=>{let w=a(o.from,n),b=a(o.to,n);return{...o,from:w,to:b,gasLimit:o.gas||o.gasLimit}},c=m({netWorkId:o.chainId})?.localType||"custom-net",x=f(c)?.networkId||"custom-net",y={chainId:o.chainId,networkId:x,name:c},C={common:t.custom(y,{baseChain:n,hardfork:e.London})},{TransactionFactory:A}=await s();return A.fromTxData(i(),C)},_=async(o,t)=>{let e=o.toJSON();e.type=o.type;let{TransactionFactory:n}=await s(),i=n.fromTxData({...e,...t},{common:o.common,freeze:Object.isFrozen(o)});return(0,r.bufferToHex)(i.serialize())},D="0x2019",j=({chainId:o,method:t})=>D===o&&t===p.KAIA_SIGN_TRANSACTION;export{W as a,_ as b,j as c};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-UR3FOE2D.js.map
