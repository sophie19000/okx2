import{a}from"./chunk-BO74ZZWP.js";import{Ja as m}from"./chunk-BY6GMUSF.js";import{f as r,o as e,p as s,q as t}from"./chunk-6567QU4Q.js";e();t();var o=r(a()),d=r(m()),x=(n,i)=>{let f=s.Buffer.from((0,d.stripHexPrefix)(n),"hex");return o.TransactionFactory.fromSerializedData(f).getSenderAddress().toString()===i},p=x;export{p as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-G3WOYQW3.js.map
