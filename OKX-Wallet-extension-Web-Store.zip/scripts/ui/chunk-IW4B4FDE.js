import{b as n}from"./chunk-DYGV7JBI.js";import{g as r}from"./chunk-DSGCARHA.js";import{o as t,q as e}from"./chunk-6567QU4Q.js";t();e();var s=(o,...c)=>u=>(...i)=>{o?.(...c),u?.(...i)},f=s;t();e();var a=n(r),k=a;export{f as a,k as b};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-IW4B4FDE.js.map
