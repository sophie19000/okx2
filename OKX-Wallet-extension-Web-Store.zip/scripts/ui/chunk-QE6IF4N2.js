import{b as l}from"./chunk-VND3RKVB.js";import{f,o as s,q as o}from"./chunk-6567QU4Q.js";s();o();var _=f(l());var d=({priorityMode:i,manualType:t,jitoIsSuccess:a,mevUnstableShowLevel:u})=>{let e=i==="auto",n=t===1,r=t===0;return(0,_.useMemo)(()=>e?u===1?3:u===0?2:a?0:1:r?u===0?5:u===1?6:4:n?u===1?9:u===0?8:7:0,[e,n,r,a,u])};export{d as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-QE6IF4N2.js.map
