import{a as s}from"./chunk-GPUFECCR.js";import{W as e}from"./chunk-HEHV4WEB.js";import{b as i}from"./chunk-VND3RKVB.js";import{f as t,o,q as r}from"./chunk-6567QU4Q.js";o();r();var _=t(i()),I=t(s());o();r();var u={root:"_root_9u2ip_1",flip:"_flip_9u2ip_10"};function w({className:l,style:c,flip:f,...a}){return _.default.createElement(e,{className:(0,I.default)("okx-wallet-plugin-select-unfold",u.root,{[u.flip]:f},l),style:c,...a})}var T=w;o();r();o();r();var b=t(i());o();r();var d=t(i()),x=t(s());o();r();var p={root:"_root_13sam_1",right:"_right_13sam_5",top:"_top_13sam_8",bottom:"_bottom_13sam_11"};var n={TOP:"top",LEFT:"left",RIGHT:"right",BOTTOM:"bottom"},y={[n.TOP]:p.top,[n.RIGHT]:p.right,[n.BOTTOM]:p.bottom};function g({className:l,style:c,side:f,icon:a="okx-wallet-plugin-back",...k}){return d.default.createElement(e,{className:(0,x.default)(a,p.root,y[f],l),style:c,...k})}g.SIDE=n;var h=g;o();r();var O=t(i()),S=t(s());o();r();export{T as a,h as b};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-3MLC3ATF.js.map
