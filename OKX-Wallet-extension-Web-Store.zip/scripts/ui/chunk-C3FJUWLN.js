import{$d as i,Kd as r}from"./chunk-BY6GMUSF.js";import{o as t,q as e}from"./chunk-6567QU4Q.js";t();e();i();var p=n=>r.MPC===n;export{p as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-C3FJUWLN.js.map
