import{b as c}from"./chunk-VND3RKVB.js";import{f as u,o as e,q as n}from"./chunk-6567QU4Q.js";e();n();var t=u(c()),r=(0,t.createContext)({gasReturn:{status:null,activityId:null,activity:null,tip:null,clear:()=>{}}});function a(){return(0,t.useContext)(r)}function l(){return a()?.gasReturn||{}}function s({children:i,...o}){return t.default.createElement(r.Provider,{value:o},i)}export{l as a,s as b};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-E6FBXKBM.js.map
