import{c as _}from"./chunk-CNB6L4QB.js";import{r as a}from"./chunk-VJV3G3PD.js";import{c as n}from"./chunk-OEZTX2LV.js";import{G as T,x as s}from"./chunk-UO3B6UBI.js";import{A as l}from"./chunk-CB5UL2JJ.js";import{b as f}from"./chunk-VND3RKVB.js";import{f as y,o as i,q as p}from"./chunk-6567QU4Q.js";i();p();var o=y(f());T();i();p();var m={root:"_root_1itou_1",name:"_name_1itou_5",value:"_value_1itou_11"};var u=({name:e,value:r})=>{let t=_({showDesc:!1});return o.default.createElement(n.Box,{className:m.root},o.default.createElement(a.Text,{ellipsis:{tooltip:!0},className:m.name},e||s("wallet_dapp_connection_subtitle_data_label")),o.default.createElement(n.Box,{className:m.value},o.default.createElement(l,{title:s("wallet_receive_btn_copy_address"),type:l.TYPES.neutral,trigger:l.TRIGGER_TYPES.hover},o.default.createElement(a.Text,{size:a.SIZE.sm,onClick:()=>{t(r)}},r))))},d=({message:e})=>typeof e=="string"?o.default.createElement(u,{value:e}):o.default.createElement("div",null,e.map(({name:r,value:t})=>(typeof t=="boolean"&&(t=t.toString()),o.default.createElement(u,{name:r,value:t})))),C=d;export{C as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-LF6EFET2.js.map
