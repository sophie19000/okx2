import{a}from"./chunk-6CMAVHI6.js";import{e as l}from"./chunk-AR3LFE2T.js";import{G as s,x as o}from"./chunk-UO3B6UBI.js";import{d as r}from"./chunk-CB5UL2JJ.js";import{o as t,q as e}from"./chunk-6567QU4Q.js";t();e();s();var p=({unapproved:n})=>{let i=a(n);return l(i.initialType)?{type:r.TYPE.error,message:o("wallet_extension_top_toast_dapp_comingsoon")}:null},d=p;export{d as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-O3C2SMZK.js.map
