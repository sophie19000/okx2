import{a as d}from"./chunk-C3FJUWLN.js";import{c as a,f as y}from"./chunk-AR3LFE2T.js";import{H as I}from"./chunk-SJNNRA35.js";import{$c as g,$d as P,Hc as f,Rd as m,Sd as u,yc as c}from"./chunk-BY6GMUSF.js";import{o as p,q as C}from"./chunk-6567QU4Q.js";p();C();P();g();function B({coin:i,walletIdentity:e,options:o={}}){let{needFilterBaseCoin:t=!1,isKeystone:n,isMPC:r,isHardWallet:s}=o,W=n??a(e?.initialType),F=s??y(e?.keyringIdentityType),l=r??d(e?.keyringIdentityType);return!l&&!F?!0:t&&I(i)?!!l:W&&i.baseCoinId===c&&i.coinId===f?!1:l?!Object.values(u).includes(i.protocolId):!Object.values(m).includes(i.protocolId)}function O({coins:i=[],walletIdentity:e,options:o={}}){let t=a(e?.initialType),n=y(e?.keyringIdentityType),r=d(e?.keyringIdentityType);return i.filter(s=>B({coin:s,walletIdentity:e,options:{...o,isMPC:r,isHardWallet:n,isKeystone:t}}))}export{B as a,O as b};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-5ABR4DNQ.js.map
