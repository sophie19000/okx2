import{j as p,p as F}from"./chunk-X34OZWQX.js";import{f as n,i as k}from"./chunk-N5VT2JC5.js";import{Q as T,R as d,U as b}from"./chunk-RCREB6RR.js";import{a as f}from"./chunk-PNQHXYIW.js";import{b as s,c as m,e as S}from"./chunk-OPUCCACO.js";import{f as g,o as i,q as c}from"./chunk-6567QU4Q.js";i();c();var a=g(f());S();F();k();b();function I(e){return t=>{a.default.debug("background.setFirstTimeFlowType"),s().setFirstTimeFlowType(e,o=>{o&&t(n(o.message))}),t({type:T,value:e})}}function P(e){return t=>(a.default.debug("background.setSeedPhraseBackedUp"),new Promise((o,u)=>{s().setSeedPhraseBackedUp(e,r=>{if(r){t(n(r.message)),u(r);return}p(t).then(o).catch(u)})}))}function l(e){return{type:d,value:e}}function U(){return async e=>{let t=await m().getRequestAccountTabIds();e(l(t))}}export{I as a,P as b,U as c};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-Q66BX64O.js.map
