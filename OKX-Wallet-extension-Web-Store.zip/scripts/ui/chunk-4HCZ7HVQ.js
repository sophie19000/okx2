import{b as c}from"./chunk-DYGV7JBI.js";import{ic as l,n}from"./chunk-SJNNRA35.js";import{I as u,ra as C}from"./chunk-2A3K6ORU.js";import{b as S}from"./chunk-VND3RKVB.js";import{f as m,o as e,q as r}from"./chunk-6567QU4Q.js";e();r();var f=m(l());e();r();var d=t=>o=>o.metamask[t],p=t=>c(d(t));var U=()=>(0,f.useSelector)(n),V=p("selectedCurrency");e();r();var s=m(S());C();function k(t,o=u){let[a,g]=(0,s.useState)(t);return(0,s.useLayoutEffect)(()=>{o(t,a)||g(t)},[t,o,a]),a}var L=k;export{U as a,V as b,L as c};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-4HCZ7HVQ.js.map
