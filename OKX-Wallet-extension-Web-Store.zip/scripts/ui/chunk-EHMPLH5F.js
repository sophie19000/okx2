import{T as a,U as m}from"./chunk-RCREB6RR.js";import{k as i,l as p}from"./chunk-PNQHXYIW.js";import{b as c,e as g}from"./chunk-OPUCCACO.js";import{o as r,q as o}from"./chunk-6567QU4Q.js";r();o();p();g();m();var d=i({name:"walletConfig",initialState:{},reducers:{}}),{reducer:w}=d,W=w;function x(e){return{type:a,value:e}}function C(e,l){return s=>new Promise((u,f)=>{c().setWalletConfig(e,l,(t,n)=>{if(t){f(t);return}s(x(n)),u(n)})})}function A(e){return C("hasShowDisconnectUpgrade",e)}function E({metamask:e}){return e.walletConfig}export{W as a,C as b,A as c,E as d};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-EHMPLH5F.js.map
