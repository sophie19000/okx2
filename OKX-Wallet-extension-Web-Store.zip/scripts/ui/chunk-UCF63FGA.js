import{b as a}from"./chunk-WGOX6RIB.js";import{La as r}from"./chunk-2VNSL6BU.js";import{j as e,ra as S}from"./chunk-2A3K6ORU.js";import{o as s,q as c}from"./chunk-6567QU4Q.js";s();c();S();var g=()=>{let{useMemeStore:d}=a().hooks,{accountStore:o,commonStore:i,configStore:m}=d(),t=e(m,"computedNativeTokenInfo",{}),n=e(t,"chainId",""),u=e(t,"chainName",""),I=e(t,"tokenSymbol","");return{chainId:n,chainName:u,chainSymbol:I,businessType:r.SWAP_ORDER,accountId:o?.computedAccountId,userUniqueId:i?.userUniqueId,walletId:o.computedAccountId,userWalletAddress:o?.getAddressByChainId(+n),walletAddress:o?.getAddressByChainId(+n)}};export{g as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-UCF63FGA.js.map
