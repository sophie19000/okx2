import{c as t,o,q as n}from"./chunk-6567QU4Q.js";var e=t((i,p)=>{o();n();function c(){}p.exports=c});export{e as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-2GXVHK6S.js.map
