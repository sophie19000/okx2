import{a as s}from"./chunk-KYC75UXK.js";import{h as o}from"./chunk-YVRQH7O3.js";import{o as e,q as c}from"./chunk-6567QU4Q.js";e();c();var u=t=>{let l=t?.walletId,n=t?.localType,r=o(l),a=s(n,l);return{...r,address:a}},f=u;export{f as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-6CMAVHI6.js.map
