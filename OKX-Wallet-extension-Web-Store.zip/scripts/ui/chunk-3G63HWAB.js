import{o as t,q as o}from"./chunk-6567QU4Q.js";t();o();var n={get fontFamily(){return window.getComputedStyle(document.body).fontFamily}};export{n as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-3G63HWAB.js.map
