import{a as o,b as u,c as i,d as a,e as p,f as c,g as T,h as g}from"./chunk-OOQVDTAR.js";import{ic as I}from"./chunk-SJNNRA35.js";import{f as l,o as s,q as n}from"./chunk-6567QU4Q.js";s();n();var t=l(I());function e(x,r){return()=>{let d=(0,t.useSelector)(x),f=(0,t.useDispatch)();function m(h){r&&f(r(h))}return{value:d,setValue:m}}}var y=e(o,p),B=e(u,c),C=e(i,T),E=e(a,g);export{y as a,B as b,C as c,E as d};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-35DK7ETY.js.map
