import{g as u}from"./chunk-YVRQH7O3.js";import{b as c}from"./chunk-BWN7OXQT.js";import{o as k}from"./chunk-GT42CPWV.js";import{Aa as C,Ad as _,lb as m,qd as a,ub as W,za as n}from"./chunk-BY6GMUSF.js";import{G as b,o as f}from"./chunk-UO3B6UBI.js";import{j as i,ra as L}from"./chunk-2A3K6ORU.js";import{b as E}from"./chunk-VND3RKVB.js";import{f as r,o,q as s}from"./chunk-6567QU4Q.js";o();s();var l=r(E()),p=r(k());L();b();_();C();W();var T="update_defi_list",M=()=>{let d=u(),I=a(),t=(0,p.useRequest)(async()=>{let D=await m(n.getDefiList,{accountId:d});return i(D,["data","platformListByAccountId","0","platformListVoList"],[]).filter(g=>I.find(h=>Number(h.netWorkId)===g.chainId))},{manual:!0}),e=c("invest-DeFi",{onError:t.refresh,pollingInterval:30*1e3});return(0,l.useEffect)(()=>{e&&t.refresh()},[e]),f.listen(T,t.refresh,!1),t};export{T as a,M as b};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-QHLSSPDF.js.map
