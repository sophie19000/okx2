import{G as p,H as c,M as d,N,U as a,d as r,e as o,f as u,h as i}from"./chunk-RCREB6RR.js";import{b as E,o as e,q as t}from"./chunk-6567QU4Q.js";function x(){return{type:r}}function L(n){return{type:o,value:n}}function A(n=void 0){return{type:u,value:n}}function S(n=void 0){return{type:p,value:n}}function R(){return{type:c}}function g(n){return{type:i,value:n}}function C(){return{type:d}}function G(){return{type:N}}var O=E(()=>{"use strict";e();t();a()});export{x as a,L as b,A as c,S as d,R as e,g as f,C as g,G as h,O as i};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-N5VT2JC5.js.map
