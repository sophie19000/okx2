import{a}from"./chunk-XGKINH42.js";import"./chunk-VHRA6MQ5.js";import"./chunk-VTSPDYAY.js";import"./chunk-6567QU4Q.js";export{a as default};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=Btc-DXUFFOLK.js.map
