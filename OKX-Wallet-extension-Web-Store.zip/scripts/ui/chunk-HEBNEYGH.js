import{o as r,q as a}from"./chunk-6567QU4Q.js";r();a();function g(o){return o.reduce((e,n)=>(n.childrenCoin?.length?n.childrenCoin.forEach(i=>{e.push(i)}):e.push(n),e),[])}export{g as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-HEBNEYGH.js.map
