import{pa as r}from"./chunk-ZBTXKGF6.js";import{ra as i}from"./chunk-BY6GMUSF.js";import{o,q as t}from"./chunk-6567QU4Q.js";o();t();i();function p(e){return r(e,{fromNumericBase:"hex",toNumericBase:"dec"})}function s(e){return r(e,{fromNumericBase:"dec",toNumericBase:"hex"})}export{p as a,s as b};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-4WCXSYVQ.js.map
