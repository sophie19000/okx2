import{k as l,l as E}from"./chunk-PNQHXYIW.js";import{o as a,q as i}from"./chunk-6567QU4Q.js";a();i();E();var O="dialog",p={["REMOVE_ACCOUNT"]:{isOpen:!1,accountId:"",keyringType:""}},C=l({name:O,initialState:p,reducers:{openDialog(e,o){o.payload.type==="REMOVE_ACCOUNT"&&(e["REMOVE_ACCOUNT"]={...e["REMOVE_ACCOUNT"],...o.payload,isOpen:!0})},closeDialog(e,o){o.payload.type==="REMOVE_ACCOUNT"&&(e["REMOVE_ACCOUNT"]=p["REMOVE_ACCOUNT"])}}}),{actions:T,reducer:t,name:r}=C,{openDialog:y,closeDialog:g}=T;var s=t;export{r as a,y as b,g as c,s as d};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-6XHU2KRP.js.map
