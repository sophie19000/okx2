import{o as e,q as r}from"./chunk-6567QU4Q.js";e();r();var p={wrapper:"_wrapper_1e2n5_1",dialogHeader:"_dialogHeader_1e2n5_9",headerIcon:"_headerIcon_1e2n5_15",toolkitWrapper:"_toolkitWrapper_1e2n5_19"};export{p as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-V3QUFHAW.js.map
