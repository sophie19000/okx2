import{Aa as c,lb as r,pb as n,ub as u,za as o}from"./chunk-BY6GMUSF.js";import{o as s,q as p}from"./chunk-6567QU4Q.js";s();p();u();c();var S=(t,e)=>r(o.getScanStatus,t,e),i=(t,e)=>r(o.getAccountInfo,t,e),l=(t,e)=>r(o.getUserId,t,e),m=(t,e)=>n(o.postWalletStatus,t,e);var h=(t,e)=>n(o.postMPCCheck,t,e);export{S as a,i as b,l as c,m as d,h as e};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-DLOZVW5E.js.map
