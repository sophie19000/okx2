import{o as e,q as r}from"./chunk-6567QU4Q.js";e();r();e();r();var s=()=>({cloudResetTip:()=>{},handleCloudResetError:u=>!1}),t=s;var R=t;export{R as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-BTVUCVMP.js.map
