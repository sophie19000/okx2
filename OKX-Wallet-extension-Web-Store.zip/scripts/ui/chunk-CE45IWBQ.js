import{c as C}from"./chunk-S5AJVP42.js";import{b as w}from"./chunk-QG4FJSYG.js";import{a as k}from"./chunk-L2FOM6YJ.js";import{b as a}from"./chunk-FHY26F73.js";import{e as N}from"./chunk-B4PNOZJQ.js";import{k as f}from"./chunk-YNJWLJZS.js";import{j as c}from"./chunk-Z4N45TGK.js";import{$c as I,Sb as y,Tb as u,yb as p}from"./chunk-BY6GMUSF.js";import{b as M}from"./chunk-VND3RKVB.js";import{f as P,o as i,q as m}from"./chunk-6567QU4Q.js";i();m();var l=P(M());I();y();var _=({origin:d})=>{let{provider:o,status:R}=C({dappUrl:d}),n=w(o),{rpcNetworks:h}=N(),s=h?.map(f)||[],t=k(),e=c?.[o];return{chain:(0,l.useMemo)(()=>e?e===u?t.concat(s).find(r=>a(n,r))||null:o===p?t.find(r=>r.chainId===n.chainId)||null:t.find(r=>r.baseChain===e)||null:null,[e,t,n,s,o]),status:R}};export{_ as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-CE45IWBQ.js.map
