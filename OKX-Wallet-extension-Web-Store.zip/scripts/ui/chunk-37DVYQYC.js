import{c as r}from"./chunk-BY6GMUSF.js";import{f as t,n as process,o as i,q as n}from"./chunk-6567QU4Q.js";i();n();var e=t(r()),s={version:e.default.runtime.getManifest().version,manifest:e.default.runtime.getManifest(),id:e.default.runtime.id,buildType:process.env.ASSETS_BUILD_TYPE};export{s as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-37DVYQYC.js.map
