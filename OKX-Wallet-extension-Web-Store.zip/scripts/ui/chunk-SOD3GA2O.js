import{b as n}from"./chunk-ZSBIVYRR.js";import{a as C}from"./chunk-GPUFECCR.js";import{b}from"./chunk-VND3RKVB.js";import{f as r,o as t,q as e}from"./chunk-6567QU4Q.js";t();e();var i=r(b()),p=r(C());t();e();var s={disabled:"_disabled_d2nbg_1"};var v=({children:a,use:l=!0,className:d})=>{let{isMoonCat:u,loadingMoonCatData:c}=n(),m=o=>{o.stopPropagation(),o.preventDefault()},f=o=>{o.stopPropagation(),o.preventDefault()};return l&&(c||u)?i.default.createElement("div",{className:(0,p.default)(s.disabled,d),tabIndex:-1,onClickCapture:m,onKeyDownCapture:f,role:"button","aria-disabled":"true"},a):a},N=v;export{N as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-SOD3GA2O.js.map
