import{o as e,q as t}from"./chunk-6567QU4Q.js";e();t();var s=o=>new Promise(r=>{setTimeout(()=>{r()},o)}),u=s;export{u as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-NHFLEMTP.js.map
