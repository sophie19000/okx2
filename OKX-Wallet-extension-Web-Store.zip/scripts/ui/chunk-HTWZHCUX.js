import{a as e}from"./chunk-ABG3OKBL.js";import{G as r,x as s}from"./chunk-UO3B6UBI.js";import{o,q as t}from"./chunk-6567QU4Q.js";o();t();r();var a=()=>e("host")?.data??s("wallet_common_okx_link"),i=a;export{i as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-HTWZHCUX.js.map
