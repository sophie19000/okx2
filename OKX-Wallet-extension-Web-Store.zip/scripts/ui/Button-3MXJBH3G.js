import{ea as a}from"./chunk-HEHV4WEB.js";import"./chunk-4UJOISFS.js";import"./chunk-VND3RKVB.js";import"./chunk-UEFE5572.js";import"./chunk-7PSYCF2F.js";import"./chunk-6567QU4Q.js";export{a as default};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=Button-3MXJBH3G.js.map
