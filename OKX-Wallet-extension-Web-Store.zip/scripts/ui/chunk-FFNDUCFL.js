import{G as u,h as o}from"./chunk-UO3B6UBI.js";import{b as a}from"./chunk-4OTMAL53.js";import{f as d,o as e,q as n}from"./chunk-6567QU4Q.js";e();n();var i=d(a());u();var r=Number.MAX_SAFE_INTEGER,t=null;function m(){return t===null&&(t=Math.round(o.mathRandom()*r)),t%=r,t++}export{m as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-FFNDUCFL.js.map
