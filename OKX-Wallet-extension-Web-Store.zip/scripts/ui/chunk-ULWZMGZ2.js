import{a as c}from"./chunk-UIUNVP3N.js";import{o as p}from"./chunk-GT42CPWV.js";import{Eb as n,ic as i}from"./chunk-SJNNRA35.js";import{b as f}from"./chunk-VND3RKVB.js";import{f as t,o as r,q as a}from"./chunk-6567QU4Q.js";r();a();var e=t(f()),l=t(i()),m=t(p());var M=()=>{let s=(0,l.useSelector)(n),u=(0,e.useMemo)(()=>Object.keys(s||{}),[s]),d=c(),o=(0,m.useMemoizedFn)(async()=>{await d(u,!1)});(0,e.useEffect)(()=>{o()},[o])};export{M as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-ULWZMGZ2.js.map
