import{o as _,q as R}from"./chunk-6567QU4Q.js";_();R();var E="import_private_key_repeat";var t="import_seed_phrase_repeat";export{E as a,t as b};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-FVXYZ3FW.js.map
