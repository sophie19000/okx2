import{_ as l}from"./chunk-SRQ2ZS4K.js";import{h as p}from"./chunk-YVRQH7O3.js";import{b as c}from"./chunk-VND3RKVB.js";import{f as a,o as t,q as e}from"./chunk-6567QU4Q.js";t();e();var y=a(c());var m={"MNEMONIC WALLET":"seed_phrase","PRIVATE KEY WALLET":"private_key","MPC WALLET":"mpc","HARDWARE WALLET":"hardware"},A=r=>{let n=p(r),i=m[n?.keyringIdentityType];return(0,y.useCallback)(o=>{l({wallet_type:i,...o,wallet_id:n?.walletId,page_type:o.page_type||o.trade})},[i,r])};t();e();export{A as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-OZO7DJSV.js.map
