import{o as u,q as p}from"./chunk-6567QU4Q.js";u();p();var n=a=>{let t=a===2,c=a===0,o=t||c;return{needBackup:a,hasBackup:o,hasCloudBackup:t,hasManualBackup:c,isNotBackupWallet:!o}},k=n;export{k as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-NSJ6Z6YP.js.map
