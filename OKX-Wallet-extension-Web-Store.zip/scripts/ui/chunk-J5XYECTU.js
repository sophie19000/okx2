import{a as c}from"./chunk-RKBUK4AS.js";import{b as n}from"./chunk-VND3RKVB.js";import{f as r,o,q as t}from"./chunk-6567QU4Q.js";o();t();var u=r(n()),a=r(c());function m(){let{search:e}=(0,a.useLocation)();return u.default.useMemo(()=>new URLSearchParams(e),[e])}var f=m;export{f as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-J5XYECTU.js.map
