import{o,q as s}from"./chunk-6567QU4Q.js";o();s();var c=(t="")=>{let n=t.trim().split("&").map(e=>e.split("=")),r={};return n.forEach(e=>{e[0]&&(r[e[0]]=decodeURIComponent(e[1]))}),r},i=(t={})=>`?${Object.entries(t).map(e=>`${e[0]}=${encodeURIComponent(e[1])}`).join("&")}`;export{c as a,i as b};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-FPI7BAMT.js.map
