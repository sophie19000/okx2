import{a as m}from"./chunk-XFQNCU35.js";import{c as a}from"./chunk-EHMPLH5F.js";import{Pb as p,ic as l}from"./chunk-SJNNRA35.js";import{b as d}from"./chunk-VND3RKVB.js";import{f as n,o as c,q as i}from"./chunk-6567QU4Q.js";c();i();var e=n(d());var t=n(l());var w=()=>{let{hasShowDisconnectUpgrade:r}=m(),{defaultWallet:s}=(0,t.useSelector)(p),f=(0,t.useDispatch)(),o=(0,e.useMemo)(()=>!r&&s==="HIJACK",[r,s]),u=(0,e.useCallback)(()=>{o&&f(a(!0))},[o]);return{isNeedShowDisconnectUpgrade:o,setDisconnectUpgrade:u}};export{w as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-KSXRIYH2.js.map
