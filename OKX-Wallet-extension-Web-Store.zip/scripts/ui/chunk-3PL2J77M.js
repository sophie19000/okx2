import{Aa as i,pb as o,ub as m,za as t}from"./chunk-BY6GMUSF.js";import{o as e,q as r}from"./chunk-6567QU4Q.js";e();r();i();m();var l=n=>{let f=t.getZKTransferFee;return o(f,n)};export{l as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-3PL2J77M.js.map
