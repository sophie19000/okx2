import{ic as e,m as i}from"./chunk-SJNNRA35.js";import{f as t,o,q as r}from"./chunk-6567QU4Q.js";o();r();var p=t(e());function s(){return(0,p.useSelector)(i)}export{s as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-EKMLWFNU.js.map
