import{o as _,q as A}from"./chunk-6567QU4Q.js";_();A();

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-SPQ3GNBC.js.map
