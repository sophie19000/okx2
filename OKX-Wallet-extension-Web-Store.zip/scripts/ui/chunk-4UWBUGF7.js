import{b as p,c as s,d as u,g as x,o as t,q as l}from"./chunk-6567QU4Q.js";var r={};u(r,{default:()=>d});var d,i=p(()=>{t();l();d={}});var n=s((q,f)=>{t();l();var e=(i(),x(r));if(e&&e.default){f.exports=e.default;for(let o in e)f.exports[o]=e[o]}else e&&(f.exports=e)});export{n as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-4UWBUGF7.js.map
