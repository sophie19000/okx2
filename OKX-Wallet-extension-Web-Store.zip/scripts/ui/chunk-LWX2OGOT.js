import{l as c,s as u,t as m}from"./chunk-MKY23TEU.js";import{a as p}from"./chunk-DYGV7JBI.js";import{g as I}from"./chunk-YVRQH7O3.js";import{o as F}from"./chunk-GT42CPWV.js";import{ic as L}from"./chunk-SJNNRA35.js";import{f as l,o as i,q as a}from"./chunk-6567QU4Q.js";i();a();var f=l(F());i();a();var N=l(F());var d=l(L());var b=()=>{let e=I(),o=(0,d.useDispatch)();return{resetData:(0,N.useMemoizedFn)(()=>{o(m({walletId:e,nftListData:void 0}))})}},D=b;var v=p(c,u),x=()=>{let{resetData:e}=D(),[o,s]=v(),T=(0,f.useMemoizedFn)((r=!1)=>{let t={collectionFilter:[],saleStatusFilter:[]};return r&&e(),s(t),t}),h=(0,f.useMemoizedFn)((r,t=!1)=>{let n={...o,collectionFilter:r};return t&&e(),s(n),n}),g=(0,f.useMemoizedFn)((r,t=!1)=>{let n={...o,saleStatusFilter:r};return s(n),t&&e(),n});return{filterInfo:o,changeFilterInfo:(r,t=!1)=>{t&&e(),s({...o,...r})},resetFilterInfo:T,changeCollectionFilter:h,changeSaleStatusFilter:g,resetData:e}},j=x;export{j as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-LWX2OGOT.js.map
