import{f as n}from"./chunk-ALL32FYB.js";import{h as m}from"./chunk-YVRQH7O3.js";import{H as a,a as o}from"./chunk-ZDCNELFZ.js";import{a as T}from"./chunk-RKBUK4AS.js";import{f,o as t,q as e}from"./chunk-6567QU4Q.js";t();e();var r=f(T());function A(){let c=(0,r.useHistory)(),l=m();return()=>{let s=`${a}/${n.CREATE}`,{keyringName:p="",walletName:i=""}=l||{},u=`${p}-${i}`;c.push({pathname:s,state:{walletName:u,anim:"1",next:o}})}}var U=A;export{U as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-7JF4JVUF.js.map
