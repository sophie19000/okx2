import{c as a,o as e,q as o}from"./chunk-6567QU4Q.js";var l=a((R,t)=>{e();o();t.exports=globalThis.ReactRouterDOM});export{l as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-RKBUK4AS.js.map
