import{a as n}from"./chunk-WFAY6DYI.js";import{X as c,_ as a,i as r}from"./chunk-ZDCNELFZ.js";import{o as t,q as d}from"./chunk-6567QU4Q.js";t();d();function m({isRpcMode:f,lastOptType:e,permissionsRequestId:i,isNotBackup:o}){if(f){if(e===n.connect&&!o)return`${r}/${i}`;if([n.msg,n.addToken,n.addChain,n.transaction].includes(e))return c}else if(!o){if([n.transaction,n.addToken,n.addChain].includes(e))return a;if(e===n.connect)return`${r}/${i}`}return""}export{m as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-SRMXE24O.js.map
