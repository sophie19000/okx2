import{o as l,q as e}from"./chunk-6567QU4Q.js";l();e();l();e();var u=()=>({isCloudChecked:!0,onboardingRedirectCallBack:null,onCloudUpdatedCallBack:null,onCloudResetLocalCallBack:null}),o=u;var n=o;export{n as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-3FVO7D6V.js.map
