import{K as o,U as n}from"./chunk-RCREB6RR.js";import{o as r,q as t}from"./chunk-6567QU4Q.js";r();t();n();function a(e={},{type:c,value:s}){switch(c){case o:return{...e,current:s.messages,okdCurrent:s.okdMessages,dexCurrent:s.dexMessages,discoverCurrent:s.discoverMessages};default:return e}}var d=e=>e.localeMessages.current,l=e=>e.localeMessages.okdCurrent,M=e=>e.localeMessages.dexCurrent;export{a,d as b,l as c,M as d};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-2GD564NM.js.map
