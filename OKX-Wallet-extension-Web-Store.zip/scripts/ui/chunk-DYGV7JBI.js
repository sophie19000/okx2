import{ic as i}from"./chunk-SJNNRA35.js";import{f as a,o as c,q as n}from"./chunk-6567QU4Q.js";c();n();var e=a(i()),V=(t,r)=>()=>{let o=(0,e.useSelector)(t),s=(0,e.useDispatch)();return[o,u=>{r&&s(r(u))}]},h=t=>()=>(0,e.useSelector)(t);export{V as a,h as b};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-DYGV7JBI.js.map
