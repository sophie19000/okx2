import{c,o as t,q as o}from"./chunk-6567QU4Q.js";var i=c((b,a)=>{"use strict";t();o();var T="SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED";a.exports=T});var h=c((I,m)=>{"use strict";t();o();var O=i();function u(){}function y(){}y.resetWarningCache=u;m.exports=function(){function e(_,v,P,d,E,f){if(f!==O){var p=new Error("Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types");throw p.name="Invariant Violation",p}}e.isRequired=e;function r(){return e}var n={array:e,bool:e,func:e,number:e,object:e,string:e,symbol:e,any:e,arrayOf:r,element:e,elementType:e,instanceOf:r,node:e,objectOf:r,oneOf:r,oneOfType:r,shape:r,exact:r,checkPropTypes:y,resetWarningCache:u};return n.PropTypes=n,n}});var R=c((C,l)=>{t();o();l.exports=h()();var q,x});export{R as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-4UJOISFS.js.map
