import{f as c,i as x}from"./chunk-N5VT2JC5.js";import{L as p,U as m}from"./chunk-RCREB6RR.js";import{b as s,e as l}from"./chunk-OPUCCACO.js";import{o as u,q as i}from"./chunk-6567QU4Q.js";u();i();x();l();m();function P(e){return{type:p,value:e}}function t(e,f){return n=>new Promise((a,d)=>{s().setPreference(e,f,(r,o)=>{if(r){n(c(r.message)),d(r);return}n(P(o)),a(o)})})}function C(e){return t("autoLockTimeLimit",e)}function h(e){return t("defaultWallet",e)}function T(e){return t("closeDefaultWalletPopup",e)}function g(e){return t("showNftAmount",e)}function S(e){return t("hiddenAssets",e)}function E(e){return t("sidepanelMode",e)}function N(e){return t("hiddenSmallAssets",e)}function L(e){return t("passwordType",e)}function k(e){return t("credentialId",e)}function v(e){return t("webWidget",e)}export{C as a,h as b,T as c,g as d,S as e,E as f,N as g,L as h,k as i,v as j};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-JPGFEMXH.js.map
