import{$c as h,vb as C}from"./chunk-BY6GMUSF.js";import{a as c}from"./chunk-HNWE6MTZ.js";import{Y as t,ea as i,ra as s}from"./chunk-2A3K6ORU.js";import{o as a,q as r}from"./chunk-6567QU4Q.js";a();r();s();C();c();h();var b=(o=[])=>{let[n,e]=t(i(o,"networkRank"),"isHotNetwork");return[n.concat(e),n,e]};export{b as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-QRLP5RGA.js.map
