import{a as d}from"./chunk-2DFYYD5Z.js";import{b as m}from"./chunk-VND3RKVB.js";import{f as r,o as u,q as s}from"./chunk-6567QU4Q.js";u();s();var t=r(m()),c=r(d()),f=3e3;function C(n=f){let[a,e]=(0,t.useState)(!1),o=(0,t.useRef)(null),i=()=>{clearTimeout(o.current),o.current=setTimeout(()=>{e(!1)},n)},l=(0,t.useCallback)(p=>{e(!0),i(),(0,c.default)(p)},[]);return[a,l]}var b=C;export{b as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-2EV7WEOV.js.map
