import{e as a,f as e}from"./chunk-VGLBUU3J.js";import{o as n,q as c}from"./chunk-6567QU4Q.js";n();c();var I=async t=>await e.get(`${a.CHAIN_INFO}?chainId=${t}`);var h=async t=>await e.getWithCache(`${a.GET_BATCH_REAL_CHAINID}?chainId=${t||""}`,{cacheSeconds:5*60});export{I as a,h as b};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-JDVKC3LT.js.map
