import{ia as o}from"./chunk-BY6GMUSF.js";import{o as r,q as i}from"./chunk-6567QU4Q.js";r();i();o();var g={low:"low",middle:"middle",high:"high"},h=t=>{typeof t!="string"&&(t=t.toString());let e=t?.length;return e<=16?30:e<=17?28:e<=18?26:e<=20?24:e<=22?22:e<=24?20:e<=27?18:e<=31?16:e<=36?14:12};export{g as a,h as b};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-EFYJ5IFJ.js.map
