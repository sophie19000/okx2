import{o as n,q as r}from"./chunk-6567QU4Q.js";n();r();

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-DZOM4FXS.js.map
