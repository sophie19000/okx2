import{$c as T,Ad as h,Vb as f,ma as r,ra as u,td as g}from"./chunk-BY6GMUSF.js";import{o as t,q as o}from"./chunk-6567QU4Q.js";t();o();u();h();var m=e=>{e={...e};let{networkType:n,nonce:a,gas:i,gasLimit:c,gasPrice:s,value:p,maxFeePerGas:d,maxPriorityFeePerGas:I}=e;return n?e.chainId=parseInt(g(n)?.realChainIdHex||0,16):e.chainId=parseInt(e.chainId,16),e.nonce=r(a),e.gas=r(i),e.gasLimit=r(c),e.gasPrice=r(s),e.maxFeePerGas=r(d),e.maxPriorityFeePerGas=r(I),e.value=r(p),e};t();o();T();var B=(e,n={})=>Object.values(n?.[f]).find(c=>c?.address===e);t();o();t();o();var y=(e,n)=>{n.forEach(({address:a,amount:i})=>{e[a]=i})};export{m as a,B as b,y as c};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-33QJIXWH.js.map
