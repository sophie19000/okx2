import{c,h as u,j as d}from"./chunk-YVRQH7O3.js";import{$c as x,Tb as o,Vb as m,Zc as i}from"./chunk-BY6GMUSF.js";import{b as f}from"./chunk-VND3RKVB.js";import{f as W,o as l,q as A}from"./chunk-6567QU4Q.js";l();A();var a=W(f());x();var h=(r=o,t,e)=>{let s=u(t);return(0,a.useMemo)(()=>c(s,r,e),[s,r,e])},T=(r,t=o,e)=>{let s=d(r);return(0,a.useMemo)(()=>s.map(n=>c(n,t,e)),[s,t,e])},I=(r=o,t,e)=>{let s=u(t),n=h(r,t,e);return{...s,address:n}},M=(r,t,e)=>{let s=d(r);return(0,a.useMemo)(()=>s.map(n=>({...n,address:c(n,t,e)})),[s,t,e])},b=(r,t,e=m)=>{let s=i(e);return(u(t)?.addressType?.[s]||[]).find(p=>p.address===r)?.addressType};export{h as a,T as b,I as c,M as d,b as e};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-KYC75UXK.js.map
