import{J as a,K as l,T as n,ia as i}from"./chunk-BY6GMUSF.js";import{o,q as u}from"./chunk-6567QU4Q.js";o();u();i();function g(t,e){let r=Math.pow(10,Number(e||0));return n.toPlainString(l(t,r))}function p(t,e){let r=Math.pow(10,Number(e||0));return n.toPlainString(a(t,r))}function s(t={}){return(t?.args?._to||t?.args?.[0])?.toString().toLowerCase()}function f(t={}){return t?.args?._value?.toString()}export{g as a,p as b,s as c,f as d};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-DFALMGLN.js.map
