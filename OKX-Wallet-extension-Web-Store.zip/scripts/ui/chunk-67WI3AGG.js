import{ic as i,l as r}from"./chunk-SJNNRA35.js";import{f as t,o as e,q as o}from"./chunk-6567QU4Q.js";e();o();var s=t(i());var c=()=>(0,s.useSelector)(r);export{c as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-67WI3AGG.js.map
