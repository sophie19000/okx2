import{a as e,b as a}from"./chunk-4EDAI5VQ.js";import{k as s,l as i}from"./chunk-PNQHXYIW.js";import{o as r,q as o}from"./chunk-6567QU4Q.js";r();o();i();var p={inputs:[{id:Date.now(),show:!1,value:"",error:!1}],baseChain:"",errorText:"",pwd:""},n=s({name:"batchImportPrivateKey",initialState:p,reducers:{setInputs:e("inputs"),setBaseChain:e("baseChain"),setErrorText:e("errorText"),setPwd:e("pwd")}}),t=a(n.name),h=t("inputs"),w=t("baseChain"),b=t("errorText"),f=t("pwd"),{actions:c,reducer:u}=n,{setInputs:C,setBaseChain:I,setErrorText:T,setPwd:g}=c,P=u;export{h as a,w as b,b as c,f as d,C as e,I as f,T as g,g as h,P as i};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-OOQVDTAR.js.map
