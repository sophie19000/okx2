import{c as p,o,q as s}from"./chunk-6567QU4Q.js";var a=p((l,i)=>{o();s();(function(){"use strict";var u={}.hasOwnProperty;function n(){for(var t="",e=0;e<arguments.length;e++){var r=arguments[e];r&&(t=f(t,c(r)))}return t}function c(t){if(typeof t=="string"||typeof t=="number")return t;if(typeof t!="object")return"";if(Array.isArray(t))return n.apply(null,t);if(t.toString!==Object.prototype.toString&&!t.toString.toString().includes("[native code]"))return t.toString();var e="";for(var r in t)u.call(t,r)&&t[r]&&(e=f(e,r));return e}function f(t,e){return e?t?t+" "+e:t+e:t}typeof i<"u"&&i.exports?(n.default=n,i.exports=n):typeof define=="function"&&typeof define.amd=="object"&&define.amd?define("classnames",[],function(){return n}):window.classNames=n})()});export{a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-GPUFECCR.js.map
