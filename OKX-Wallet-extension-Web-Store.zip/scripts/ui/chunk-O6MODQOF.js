import{k as r,l as c}from"./chunk-PNQHXYIW.js";import{o as t,q as o}from"./chunk-6567QU4Q.js";t();o();c();var i=r({name:"coinDetail",initialState:{memoryRouteMap:{}},reducers:{storePage:(e,a)=>{e.memoryRouteMap=a.payload}}}),{actions:m,reducer:n}=i,{storePage:u}=m;var l=e=>e.coinDetail.memoryRouteMap,y=n;export{u as a,l as b,y as c};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-O6MODQOF.js.map
