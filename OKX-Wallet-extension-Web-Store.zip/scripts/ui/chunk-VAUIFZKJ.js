import{r}from"./chunk-VJV3G3PD.js";import{G as _,x as u}from"./chunk-UO3B6UBI.js";import{b as y}from"./chunk-VND3RKVB.js";import{f,o as t,q as s}from"./chunk-6567QU4Q.js";t();s();var e=f(y());_();t();s();var o={walletAsset:"_walletAsset_1rhpe_1",unsupport:"_unsupport_1rhpe_8"};var w=(0,e.memo)(m=>{let{isRpcMode:A,currentRpcNetwork:p,hiddenAssets:l,walletAsset:n,hiddenText:a="***",unsopportCurrentNetwork:i}=m,d=()=>i?u("extension_wallet_list_not_support",{network:p?.chainName}):l?a:n||`0 ${p?.symbol}`;return e.default.createElement(e.default.Fragment,null,A?e.default.createElement(r.Text,{ellipsis:!0,className:{[o.walletAsset]:!0,[o.unsupport]:i}},d()):e.default.createElement(r.DisplayAmount,{ellipsis:!0,mode:r.LEGAL,useApproximate:!1,hidden:l?a:!1,className:o.walletAsset},n))}),C=w;export{C as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-VAUIFZKJ.js.map
