import{$d as R,Bd as r,Id as o,Jd as t,Kd as s}from"./chunk-BY6GMUSF.js";import{o as E,q as n}from"./chunk-6567QU4Q.js";E();n();R();o();var G=e=>t.LEDGER_BRIDGE_KEYRING===e,_=e=>t.TREZOR_KEYRING===e,I=e=>t.KEYSTONE_KEYRING===e,N=e=>t.ONEKEY_KEYRING===e,i=new Set([t.LEDGER_BRIDGE_KEYRING,t.TREZOR_KEYRING,t.KEYSTONE_KEYRING,t.ONEKEY_KEYRING]),y=e=>i.has(e),Y=e=>e===s.HARDWARE,a={[r.LEGACY]:"Legacy",[r.SEGWIT_NESTED_49]:"segwit_nested",[r.SEGWIT_NATIVE]:"segwit_native"};export{G as a,_ as b,I as c,N as d,y as e,Y as f,a as g};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-AR3LFE2T.js.map
