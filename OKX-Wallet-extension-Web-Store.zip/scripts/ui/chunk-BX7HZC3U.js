import{c as o,o as a,q as e}from"./chunk-6567QU4Q.js";var t=o((c,l)=>{a();e();l.exports=globalThis.ReactDOM});export{t as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-BX7HZC3U.js.map
