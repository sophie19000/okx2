import{f as p,ra as a}from"./chunk-2A3K6ORU.js";import{o as t,q as e}from"./chunk-6567QU4Q.js";t();e();t();e();a();function r(){return{successHaptic:p,impactHaptic:p}}var s=r;export{s as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-BSP3B2PI.js.map
