import{a as c}from"./chunk-GPUFECCR.js";import{L as r}from"./chunk-CB5UL2JJ.js";import{b as u}from"./chunk-VND3RKVB.js";import{f as o,o as e,q as t}from"./chunk-6567QU4Q.js";e();t();var a=o(u()),l=o(c());e();t();var s={base:"_base_2qo26_1"};var b=({loading:m,children:n,height:p,style:f={},...i})=>m?a.default.createElement(r.Input,{active:!0,className:(0,l.default)(s.base),style:{height:p,...f},...i}):n??null,I=b;export{I as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-2QWUBW5G.js.map
