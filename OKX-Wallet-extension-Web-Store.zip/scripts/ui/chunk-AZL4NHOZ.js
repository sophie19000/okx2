import{a as u}from"./chunk-GPUFECCR.js";import{W as e}from"./chunk-HEHV4WEB.js";import{b as a}from"./chunk-VND3RKVB.js";import{f as r,o,q as t}from"./chunk-6567QU4Q.js";o();t();var i=r(a()),n=r(u());o();t();var m={icon:"_icon_13h51_1"};function y({className:s="",type:c="",size:f=12,...p}){let l={fontSize:`${f}px`};return i.default.createElement(e,{className:(0,n.default)(c,m.icon,s),style:l,...p})}export{y as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-AZL4NHOZ.js.map
