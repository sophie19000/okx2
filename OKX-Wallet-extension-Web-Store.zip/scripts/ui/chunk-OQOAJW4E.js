import{F as e,I as a}from"./chunk-BY6GMUSF.js";import{G as p,w as r}from"./chunk-UO3B6UBI.js";import{o,q as t}from"./chunk-6567QU4Q.js";o();t();p();a();var f=r.init({project:e});export{f as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-OQOAJW4E.js.map
