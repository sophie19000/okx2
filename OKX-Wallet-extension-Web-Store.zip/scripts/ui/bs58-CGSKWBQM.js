import{a}from"./chunk-TMOJR2KN.js";import"./chunk-6567QU4Q.js";export default a();

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=bs58-CGSKWBQM.js.map
