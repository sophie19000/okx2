import{b as f}from"./chunk-WFAY6DYI.js";import{f as c,i as w}from"./chunk-N5VT2JC5.js";import{a as O}from"./chunk-PNQHXYIW.js";import{c as s,e as v}from"./chunk-OPUCCACO.js";import{I as P,la as m,ra as b,u as a}from"./chunk-BY6GMUSF.js";import{f as N,o as n,q as p}from"./chunk-6567QU4Q.js";n();p();var i=N(O());w();b();P();v();function h(r,o,t,e,d,g,T,l){return async u=>{i.default.debug("background.setProviderType",r);try{await s().setProviderType(r,o,t,e,d,g,T,l)}catch(y){i.default.error(y),u(c("Had a problem changing networks!"))}}}function x(){return(r,o)=>{let t=o(),e=f(t);m()===a&&!e&&globalThis.platform.closeCurrentWindow()}}export{h as a,x as b};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-QVKCBIDM.js.map
