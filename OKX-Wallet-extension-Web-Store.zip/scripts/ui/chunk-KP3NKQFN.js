import{Ad as S,ad as I,bd as O,cd as o,id as C,jd as r,kd as t,nd as H}from"./chunk-BY6GMUSF.js";import{o as N,q as A}from"./chunk-6567QU4Q.js";N();A();S();var m=[I,o,t,O,H],n=[C,r];export{m as a,n as b};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-KP3NKQFN.js.map
