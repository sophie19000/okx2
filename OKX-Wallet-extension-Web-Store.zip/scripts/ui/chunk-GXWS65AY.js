import{g}from"./chunk-AR3LFE2T.js";import{p as h,q as b}from"./chunk-D7JIIDCW.js";import{$c as P,Ka as m,Tb as f,Vb as u,Xa as T}from"./chunk-BY6GMUSF.js";import{a as K}from"./chunk-HNWE6MTZ.js";import{ra as A,y as d}from"./chunk-2A3K6ORU.js";import{o as w,q as l}from"./chunk-6567QU4Q.js";w();l();T();K();P();A();var B=(o,t)=>async(a,e,c)=>{let r=`0/${a}`,{extendedPublicKey:s}=d(c,{path:t})||{},{hardwareDerivePubKey:i,getAddressByPublicKey:p}=await m(),n=await i(s,r),y=await p(0,{publicKey:n,addressType:g[o]});e[u][o]={path:`${t}/${r}`,publicKey:n,address:y}},M=async(o,t,a)=>{t[u]={};for(let e=0;e<b.length;e++){let{type:c,basePath:r}=b[e];await B(c,r)(o,t,a)}},S=(o,t)=>async(a,e,c)=>{let r=t+a,{extendedPublicKey:s}=d(c,{path:h})||{},{hardwareDerivePubKey:i,getAddressByPublicKey:p}=await m(),n=await i(s,r),y=await p(60,{publicKey:n});e[f][o]={path:`${h}/${r}`,address:y}};export{M as a,S as b};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-GXWS65AY.js.map
