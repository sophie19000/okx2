import{o as f}from"./chunk-GT42CPWV.js";import{Eb as y,hc as m,ic as M}from"./chunk-SJNNRA35.js";import{c as p,e as S}from"./chunk-OPUCCACO.js";import{f as i,o as c,q as d}from"./chunk-6567QU4Q.js";c();d();var s=i(M()),u=i(f());S();var g=(t,{needSyncMap:n,createdMap:e},a)=>t.filter(r=>{let o=!n[r];return a?o&&e[r]:o}),l=()=>{let t=(0,s.useSelector)(m),n=(0,s.useSelector)(y);return(0,u.useMemoizedFn)(async(e,a)=>{if(!Array.isArray(e)||Array.isArray(e)&&!e?.length)return;let r=g(e,{needSyncMap:t,createdMap:n},a);await p().update7702Status(r)})};export{l as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-UIUNVP3N.js.map
