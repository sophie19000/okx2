import{h as m}from"./chunk-6ZFJGFJD.js";import{Sb as g,ic as c}from"./chunk-SJNNRA35.js";import{b as s}from"./chunk-VND3RKVB.js";import{f as o,o as e,q as a}from"./chunk-6567QU4Q.js";e();a();var p=o(s()),t=o(c());function l(){let i=(0,t.useSelector)(g),r=(0,t.useSelector)(m),n=(0,p.useMemo)(()=>r.find(u=>u.origin===i),[i,r]);return!n||!n.origin?null:{...n,origin:n.origin,originNoPrefix:n.origin.replace(/^https?:\/\//iu,"")}}export{l as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-PWIL7VEK.js.map
