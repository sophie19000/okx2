import{a as c}from"./chunk-MXENA6ZZ.js";import{o as _}from"./chunk-GT42CPWV.js";import{ba as a}from"./chunk-SJNNRA35.js";import{G as u,x as n}from"./chunk-UO3B6UBI.js";import{H as s}from"./chunk-CB5UL2JJ.js";import{f as m,o,q as t}from"./chunk-6567QU4Q.js";o();t();var p=m(_());u();var g="wallet_inner_transfer",w=(i=a)=>{let l=c();return(0,p.useMemoizedFn)(async f=>{let r;try{r=(await i(f)).popupInfoList}catch(e){throw s.error(n("wallet_extension_transaction_error_general_check_network")),e}return r?.length&&await l(r),r})},k=w;export{g as a,k as b};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-7WS7ODRM.js.map
