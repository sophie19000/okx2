import{c as e}from"./chunk-6ZHJ6ZYV.js";import{G as s,x as r}from"./chunk-UO3B6UBI.js";import{b as f}from"./chunk-VND3RKVB.js";import{f as c,o as t,q as o}from"./chunk-6567QU4Q.js";t();o();var i=c(f());s();var p=({icon:m,host:n,name:a})=>i.default.createElement(e,{title:r("extension_contract_interaction_maintitle_request_from"),summaryList:[{icon:{src:m},title:a,desc:n}]}),d=p;export{d as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-KOCJKCG4.js.map
