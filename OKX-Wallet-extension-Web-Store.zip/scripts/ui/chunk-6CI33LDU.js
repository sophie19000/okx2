import{a as m}from"./chunk-FPI7BAMT.js";import{a as i}from"./chunk-RKBUK4AS.js";import{b as c}from"./chunk-VND3RKVB.js";import{f as o,o as e,q as t}from"./chunk-6567QU4Q.js";e();t();var s=o(c()),a=o(i());var n=()=>{let r=(0,a.useLocation)();return(0,s.useMemo)(()=>m(r.search?.slice(1)),[r.search])},l=n;export{l as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-6CI33LDU.js.map
