import{ca as a}from"./chunk-CKMW3O5Z.js";import{o as t,q as l}from"./chunk-6567QU4Q.js";t();l();function i(){let{isTelegramMiniApp:e}=a?.global;return!!e}export{i as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-UGVGSC3Z.js.map
