import{a as m,b as C,c as l,f as p}from"./chunk-MKY23TEU.js";import{g as F}from"./chunk-YVRQH7O3.js";import{o as U}from"./chunk-GT42CPWV.js";import{I as S,ra as R}from"./chunk-2A3K6ORU.js";import{f as L,o as W,q as g}from"./chunk-6567QU4Q.js";W();g();var e=L(U());R();function H(){let r=F(),y=r?{[r]:l}:{},[o,I]=(0,e.useLocalStorageState)(m,{defaultValue:y}),u=(0,e.useMemoizedFn)((t,n={})=>{if(!t)return;let i=o??{},_=i[t]??{},v={...i,[t]:{...l,..._,...n}};I(v)}),c=(0,e.useMemoizedFn)((t,n=r)=>{!n||u(n,t)}),d=(0,e.useMemoizedFn)((t,n,i=r)=>c({[t]:n},i)),h=(0,e.useMemoizedFn)((t=r)=>{!t||u(t,l)}),s=(0,e.useMemoizedFn)((t=r)=>t?o?.[t]??l:l),f=(0,e.useMemoizedFn)((t=r)=>{if(!t)return!1;let n=s(t);return!S(n,l)}),T=f(r),a=s(r),E=(0,e.useMemoizedFn)((t=a)=>p(t))(a),K=(0,e.useMemoizedFn)(()=>{d(C.hideUnverifiedCollection,l.hideUnverifiedCollection)});return{setting:o,setWalletSetting:d,setWalletSettings:c,resetWalletSetting:h,getWalletSetting:s,checkWalletHasChanged:f,hasCurrentWalletChanged:T,currentWalletSetting:a,formattedCurrentSetting:E,resetHideUnverifiedCollection:K}}var G=H;export{G as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-QB5WPILG.js.map
