import{b as r}from"./chunk-VND3RKVB.js";import{f as m,o,q as t}from"./chunk-6567QU4Q.js";o();t();var u=m(r());var a=e=>(0,u.useMemo)(()=>e===0||e===4||e===5,[e]),d=a;export{d as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-EHMMWQUB.js.map
