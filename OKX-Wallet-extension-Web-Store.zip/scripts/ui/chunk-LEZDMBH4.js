import{a as s}from"./chunk-EH7GYNWE.js";import{G as n,x as e}from"./chunk-UO3B6UBI.js";import{G as l}from"./chunk-CB5UL2JJ.js";import{b as a}from"./chunk-VND3RKVB.js";import{f as i,o as t,q as r}from"./chunk-6567QU4Q.js";t();r();t();r();var o=i(a());t();r();var f=i(a());n();t();r();var p={blue:"_blue_1j2vu_1"};var _=()=>f.default.createElement("span",{className:p.blue,onClick:()=>{s()}},e("wallet_extension_home_notification_btn_switch_servers"));n();var k=()=>(0,o.useCallback)((c=5)=>{l.error({key:"networkError",title:e("wallet_extension_toast_asset_error_try_again"),duration:c,placement:l.DIRECTION.top,desc:o.default.createElement(_,null)})},[]),u=k;var T=u;export{T as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-LEZDMBH4.js.map
