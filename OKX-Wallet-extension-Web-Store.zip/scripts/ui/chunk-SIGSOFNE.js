import{G as n,a as t}from"./chunk-UO3B6UBI.js";import{o,q as r}from"./chunk-6567QU4Q.js";o();r();o();r();n();var c=t()?()=>{}:()=>document.body,s=t()?void 0:window.getComputedStyle;o();r();o();r();

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-SIGSOFNE.js.map
