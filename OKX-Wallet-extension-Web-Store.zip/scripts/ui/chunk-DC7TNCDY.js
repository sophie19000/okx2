import{c as a}from"./chunk-J44JXKQW.js";import{l as i}from"./chunk-COE5JBMZ.js";import{ic as b}from"./chunk-SJNNRA35.js";import{b as k}from"./chunk-VND3RKVB.js";import{f as l,o as s,q as u}from"./chunk-6567QU4Q.js";s();u();var e=l(k()),f=l(b());var h=20*1e3,v=m=>{let p=(0,f.useDispatch)(),o=i(void 0,m),t=(0,e.useRef)(null);(0,e.useEffect)(()=>{let c=()=>{clearInterval(t.current),t.current=null},n=async()=>{try{let r=await o();if(!r){c();return}let d=await r.getBlockNumber();p(a(d))}catch(r){console.log(`fetch block failed 
${r}`)}};return n(),t.current=setInterval(()=>{n()},h),()=>{c()}},[o])},T=v;export{T as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-DC7TNCDY.js.map
