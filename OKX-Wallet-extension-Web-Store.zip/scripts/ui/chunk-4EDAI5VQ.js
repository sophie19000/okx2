import{o as u,q as c}from"./chunk-6567QU4Q.js";u();c();var l=(r,t)=>(e,{payload:n})=>{e[r]=n,t?.(r,n)},S=l;u();c();var o=r=>(...t)=>t?.length===1?e=>e[r][t]:t?.map(e=>n=>n[r][e]),x=o;export{S as a,x as b};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-4EDAI5VQ.js.map
