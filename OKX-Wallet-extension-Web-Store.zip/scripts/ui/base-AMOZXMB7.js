import{a}from"./chunk-56JILOVS.js";import"./chunk-AEHEN7Q6.js";import"./chunk-WPZLV2NY.js";import"./chunk-ZZQET3TJ.js";import"./chunk-E4PLG3WX.js";import"./chunk-QSQBKAIY.js";import"./chunk-4OTMAL53.js";import"./chunk-7VVFA6YO.js";import"./chunk-NUZJKKFY.js";import"./chunk-6567QU4Q.js";export default a();

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=base-AMOZXMB7.js.map
