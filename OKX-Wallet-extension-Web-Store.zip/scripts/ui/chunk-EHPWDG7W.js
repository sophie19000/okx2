var n=[{code:"en",name:"English"},{code:"zh_CN",name:"\u7B80\u4F53\u4E2D\u6587"},{code:"zh_TW",name:"\u7E41\u9AD4\u4E2D\u6587"},{code:"fr",name:"Fran\xE7ais"},{code:"ru",name:"\u0420\u0443\u0441\u0441\u043A\u0438\u0439"},{code:"vi",name:"Ti\u1EBFng Vi\u1EC7t"},{code:"id",name:"Bahasa Indonesia"},{code:"tr",name:"T\xFCrk\xE7e"},{code:"de",name:"Deutsch"},{code:"it",name:"Italiano"},{code:"pl",name:"Polski"},{code:"en_N",name:"English (India)"},{code:"pt_BR",name:"Portugu\xEAs (Brasil)"},{code:"pt_PT",name:"Portugu\xEAs (Portugal)"},{code:"es",name:"Espa\xF1ol (Espa\xF1a)"},{code:"es_419",name:"Espa\xF1ol (Latinoam\xE9rica)"},{code:"cs",name:"\u010Ce\u0161tina"},{code:"ro",name:"Rom\xE2n\u0103"},{code:"uk",name:"\u0423\u043A\u0440\u0430\u0457\u043D\u0441\u044C\u043A\u0430"},{code:"ar_EH",name:"\u0627\u0644\u0639\u0631\u0628\u064A\u0629"},{code:"ja",name:"\u65E5\u672C\u8A9E (DEX\u306E\u307F)"},{code:"fi",name:"Suomi"},{code:"sv",name:"Sevnska"}];export{n as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-EHPWDG7W.js.map
