import{a as f}from"./chunk-5IPOIKKQ.js";import{e as w}from"./chunk-VJV3G3PD.js";import{a as v}from"./chunk-PNQHXYIW.js";import{G as k,m as A}from"./chunk-UO3B6UBI.js";import{L as e,d as a,ra as x}from"./chunk-2A3K6ORU.js";import{b as S}from"./chunk-VND3RKVB.js";import{f as y,o as u,q as c}from"./chunk-6567QU4Q.js";u();c();var n=y(S());x();var P=y(v()),V=(o,r,i,s,m)=>(0,n.useCallback)((...p)=>{let t;return o&&(t=o(...p)),r&&(t=r(t)),i&&(t=i(t)),s&&(t=s(t)),m&&(t=m(t)),t},[o,r,i,s,m]),j=(o,r,i,s,m,p,t)=>(0,n.useCallback)(async(...b)=>{let g=[o,r,i,s,m,p,t].filter(a),C=f(...g);try{await C(b)}catch(N){P.default.error(N)}},[o,r,i,s,m,p,t]),q=(...o)=>async(...r)=>{await f(...o)(r)};u();c();x();k();var K=(o={amount:0,rate:0,symbol:""},r)=>{let{amount:i,rate:s,symbol:m}=o;return e(i)||e(s)||e(m)?"":w(A.mul(i,s),{currencySign:m,useApproximate:r.useApproximate}).value};export{V as a,j as b,q as c,K as d};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-3YUE4BE4.js.map
