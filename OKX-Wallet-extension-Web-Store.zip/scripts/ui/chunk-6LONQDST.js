import{a as m}from"./chunk-ZW64MJQ5.js";import{c as t}from"./chunk-OEZTX2LV.js";import{b as l}from"./chunk-VND3RKVB.js";import{f as i,o,q as e}from"./chunk-6567QU4Q.js";o();e();var a=i(l());o();e();var r={root:"_root_nxsib_1",header:"_header_nxsib_31"};function f({children:s,hidden:d=!1}){return a.default.createElement(t.Box,{className:r.root},a.default.createElement(m,{className:r.header}),d?null:s)}var L=f;export{L as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-6LONQDST.js.map
