import{o as t,q as n}from"./chunk-6567QU4Q.js";t();n();var o=()=>{},r=()=>{};var c=()=>{};t();n();export{o as a,r as b,c};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-BOGFFE2U.js.map
