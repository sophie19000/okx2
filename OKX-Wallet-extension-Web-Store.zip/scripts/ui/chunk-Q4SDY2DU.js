import{a as i}from"./chunk-OV5675FJ.js";import{b as p}from"./chunk-NST3KSUB.js";import{ic as f}from"./chunk-SJNNRA35.js";import{b as A}from"./chunk-VND3RKVB.js";import{f as o,o as e,q as t}from"./chunk-6567QU4Q.js";e();t();var s=o(A()),m=o(f());var l=()=>{let c=(0,m.useSelector)(p),r=i(c);return(0,s.useMemo)(()=>(r||[]).filter(v=>v.blackTagType),[r])};export{l as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-Q4SDY2DU.js.map
