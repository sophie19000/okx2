import{k as _}from"./chunk-AAWYNSDX.js";import{ld as f}from"./chunk-2VNSL6BU.js";import{W as m}from"./chunk-HEHV4WEB.js";import{b as i}from"./chunk-VND3RKVB.js";import{f as l,o,q as r}from"./chunk-6567QU4Q.js";o();r();var u=l(i());var v=()=>{(0,u.useEffect)(()=>{_()},[])};o();r();var n=l(i());o();r();var s=l(i()),x=({isUp:t=!1,children:a,customClassName:d="",isZero:c=!1})=>{let w=(0,s.useMemo)(()=>c?{}:{color:t?"var(--color-up-text)":"var(--color-down-text)"},[c,t]);return s.default.createElement("span",{className:d,style:w},a)};o();r();var e={container:"_container_17xnn_1",icon:"_icon_17xnn_10",error:"_error_17xnn_15","error-color":"_error-color_17xnn_18",errorColor:"_error-color_17xnn_18"};var z=({loseDiffValueTxt:t,isUp:a})=>n.default.createElement("div",{className:e.container},n.default.createElement(m,{fontSize:"28px",iconName:"okds-warning-circle-fill",className:e.icon}),n.default.createElement("span",{className:e.error},f("swaptrade_valuediff_select_title_one_value",{value:n.default.createElement(x,{customClassName:e.errorColor,isUp:a},t)})));export{z as a,v as b};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-J65UMKL2.js.map
