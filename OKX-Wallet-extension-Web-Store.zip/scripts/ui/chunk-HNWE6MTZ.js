import{b as a,o as S,q as T}from"./chunk-6567QU4Q.js";var O=a(()=>{"use strict";S();T()});export{O as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-HNWE6MTZ.js.map
