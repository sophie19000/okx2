import{Gb as s,X as l,zb as o}from"./chunk-SJNNRA35.js";import{$d as p,Ld as r}from"./chunk-BY6GMUSF.js";import{o as a,q as n}from"./chunk-6567QU4Q.js";a();n();p();var S=c=>async(u,i)=>{let e=i(),t=o(e),d=s(e,t)?.serverWalletType,m={txSource:r.NORMAL,accountId:t,walletType:d,...c};return await l(m,{walletSignParams:{needWalletSign:!0,walletId:t}})};export{S as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-GSNVUPIT.js.map
