import{o as r,q as s}from"./chunk-6567QU4Q.js";r();s();var t=class extends Error{constructor(e,n){super(e);this.name="CustomError",this.type=n}},a=t;export{a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-MHIQAAF7.js.map
