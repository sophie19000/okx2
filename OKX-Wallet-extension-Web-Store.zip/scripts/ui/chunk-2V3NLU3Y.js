import{g as e}from"./chunk-7OSPB4XE.js";import{c as s}from"./chunk-OEZTX2LV.js";import{b as n}from"./chunk-VND3RKVB.js";import{f as m,o,q as r}from"./chunk-6567QU4Q.js";o();r();var a=m(n());o();r();var t={"onboard-cover":"_onboard-cover_evpuq_1",onboardCover:"_onboard-cover_evpuq_1",video:"_video_evpuq_5"};var p=()=>{let d=e({light:"/cdn/assets/imgs/2412/9FB355F4AEDE1AA0.png",dark:"/cdn/assets/imgs/2412/87CDA1790E4C4D22.png"}),i=e({light:"static/images/onboard/cover-light.mp4",dark:"static/images/onboard/cover-dark-v3.mp4"});return a.default.createElement(s.Box,{className:t["onboard-cover"]},a.default.createElement("video",{muted:!0,autoPlay:!0,playsInline:!0,src:i,poster:d,className:t.video}))},x=p;export{x as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-2V3NLU3Y.js.map
