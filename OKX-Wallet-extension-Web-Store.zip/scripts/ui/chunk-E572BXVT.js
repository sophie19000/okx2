import{o as e,q as l}from"./chunk-6567QU4Q.js";e();l();e();l();var a=n=>{if(!n)return;let o=!1;try{o=window.location.href.includes("/sidepanel.html")}catch{}globalThis.platform.openTab({url:`fullscreen.html#${n}`}),o||window.close()},t=a;var m=t;export{m as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-E572BXVT.js.map
