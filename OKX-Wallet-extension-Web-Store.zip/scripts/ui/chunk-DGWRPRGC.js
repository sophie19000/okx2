import{a as x}from"./chunk-GPUFECCR.js";import{W as _}from"./chunk-HEHV4WEB.js";import{b as g}from"./chunk-VND3RKVB.js";import{f as p,o as n,q as s}from"./chunk-6567QU4Q.js";n();s();var t=p(g()),o=p(x());n();s();var e={icon:"_icon_10n9w_1",text:"_text_10n9w_4",green:"_green_10n9w_9",yellow:"_yellow_10n9w_12",red:"_red_10n9w_15"};var w=({icon:i,text:a,status:r="default",textClassName:c="",greenClassName:m})=>{let l=(0,t.useMemo)(()=>{let f=m||e.green;return(0,o.default)({[f]:r==="green",[e.yellow]:r==="yellow",[e.red]:r==="red"})},[r,m]);return t.default.createElement("div",{className:(0,o.default)("flex items-center",e.configItem)},i&&t.default.createElement(_,{className:(0,o.default)(i,e.icon,l),style:{fontSize:16},a11yText:"config-item"}),t.default.createElement("span",{className:(0,o.default)(e.text,l,c)},a))},D=w;export{D as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-DGWRPRGC.js.map
