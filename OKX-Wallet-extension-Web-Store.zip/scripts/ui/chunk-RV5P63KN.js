import{o as e,q as r}from"./chunk-6567QU4Q.js";e();r();

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-RV5P63KN.js.map
