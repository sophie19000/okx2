import{o as t,q as f}from"./chunk-6567QU4Q.js";t();f();var e=!1;function c(){e=!0}function r(){e=!1}function l(){return e}export{c as a,r as b,l as c};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-OZTNNO43.js.map
