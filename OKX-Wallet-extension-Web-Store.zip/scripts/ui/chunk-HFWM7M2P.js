import{G as g,t as r,u as t}from"./chunk-UO3B6UBI.js";import{o as e,q as o}from"./chunk-6567QU4Q.js";e();o();g();var u=(n,a)=>t("okex_wallet",n,a,{storageType:r.chromeStorage});export{u as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-HFWM7M2P.js.map
