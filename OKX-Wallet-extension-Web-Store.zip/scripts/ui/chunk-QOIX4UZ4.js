import{E as l,F as c,c as n}from"./chunk-AAWYNSDX.js";import{a as e}from"./chunk-ZK5MYOOR.js";import{o as s,q as i}from"./chunk-6567QU4Q.js";s();i();var u=({fromChainId:a,toChainId:t,bridgeRouter:r,pageName:o="bridge_claim"})=>{let{accountStore:d}=e();c({wallet_address:d.address,from_chain:a,to_chain:t,bridge_router:r,page_name:o,button_name:"bridge_claim_click"})};var C=(a,t,r)=>{let{accountStore:o}=e();l({wallet_address:r||o.address,button_name:a,page_name:t})},p=()=>{let{accountStore:a}=e();n({wallet_address:a.address,page_name:"bridge_claim_reward_toast",button_name:"bridge_claim_click"})};export{u as a,C as b,p as c};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-QOIX4UZ4.js.map
