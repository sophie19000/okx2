import{a as h}from"./chunk-GPUFECCR.js";import{e as l}from"./chunk-CB5UL2JJ.js";import{b as f}from"./chunk-VND3RKVB.js";import{f as g,o as r,q as i}from"./chunk-6567QU4Q.js";r();i();var o=g(f()),e=g(h());r();i();var u=({src:s,classnames:t="",backupImage:m="",style:d={}})=>{let[n,a]=(0,o.useState)(!0);return o.default.createElement("div",{className:(0,e.default)("ok-global--image-module",t),style:d},n&&o.default.createElement("div",{className:(0,e.default)("ok-global--image-loading")},o.default.createElement("div",{className:(0,e.default)("ok-global--image-loading-children")})),o.default.createElement(l,{pictureClassName:(0,e.default)("ok-global--image-bg"),style:{width:"100%",height:"100%"},src:s,onLoad:()=>{a(!1)},onError:()=>{a(!1)},errorImg:m}),o.default.createElement(l,{pictureClassName:(0,e.default)("ok-global--image"),style:{width:"100%",height:"100%"},src:s,onLoad:()=>{a(!1)},onError:()=>{a(!1)},errorImg:m}))},I=u;export{I as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-6ENC4FTX.js.map
