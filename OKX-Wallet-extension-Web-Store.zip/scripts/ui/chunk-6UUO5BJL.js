import{a as l}from"./chunk-ABG3OKBL.js";import{e as a}from"./chunk-DSGCARHA.js";import{ic as u}from"./chunk-SJNNRA35.js";import{b as m}from"./chunk-VND3RKVB.js";import{f as t,o as r,q as n}from"./chunk-6567QU4Q.js";r();n();var i=t(m()),k=t(u());var L=(c={})=>{let s=(0,k.useSelector)(a),e=l("link",{locale:s,...c});return(0,i.useMemo)(()=>{if(!e){let o=window.localStorage.getItem("okxWebLink");return o?JSON.parse(o):{}}return window.localStorage.setItem("okxWebLink",JSON.stringify(e.data)),e.data},[e])};export{L as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-6UUO5BJL.js.map
