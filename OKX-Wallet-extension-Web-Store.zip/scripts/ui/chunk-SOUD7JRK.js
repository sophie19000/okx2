import{a as p}from"./chunk-PWIL7VEK.js";import{a}from"./chunk-VGLNT24Y.js";import{b as d}from"./chunk-VND3RKVB.js";import{f as l,o,q as t}from"./chunk-6567QU4Q.js";o();t();o();t();var m=0;o();t();var s=l(d());var f=64,G=({isButtonAbsolute:n=!1,backupHeight:r=0})=>{let{isNotBackupWallet:i}=a(),e=p()?.originNoPrefix&&!i,c=(0,s.useMemo)(()=>n?r+80+m+(e?f:0):16,[n,e,r]),B=(0,s.useMemo)(()=>n?0:r+24+m+(e?f:0),[n,e,r]);return{paddingBottom:c,buttonPaddingBottom:B,absoluteBottom:r+24+m+(e?f:0)}};export{m as a,G as b};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-SOUD7JRK.js.map
