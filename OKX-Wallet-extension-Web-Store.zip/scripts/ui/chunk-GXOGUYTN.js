import{u as s}from"./chunk-IA3CMIZI.js";import{o as a,q as c}from"./chunk-6567QU4Q.js";a();c();function m(t,...e){if(typeof t=="function")return t(...e)}function g(t){let e=t,n=e.getBoundingClientRect().width,r=document.createRange();return r.setStart(e,0),r.setEnd(e,e.childNodes.length),r.getBoundingClientRect().width>n}var d=t=>{try{return new URL(t)}catch{return{hostname:t,pathname:""}}};var h=(...t)=>t.find(n=>s(n))??t[t.length-1],p=(t,e)=>Number(t)===Number(e),x=t=>{let e=new URLSearchParams(t),n={};return e.forEach((r,o)=>{n[o]=r}),n};export{m as a,g as b,d as c,h as d,p as e,x as f};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-GXOGUYTN.js.map
