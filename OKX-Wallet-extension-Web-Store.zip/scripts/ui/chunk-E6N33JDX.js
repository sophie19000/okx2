import{o as s}from"./chunk-GT42CPWV.js";import{o as e,q as t}from"./chunk-6567QU4Q.js";e();t();e();t();var{useMemoizedFn:i}=s(),l=()=>i(async()=>{let o=await globalThis.platform.getActiveTabs();await globalThis.platform.closeTab(o.map(({id:r})=>r))},[]),a=l;var b=a;export{b as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-E6N33JDX.js.map
