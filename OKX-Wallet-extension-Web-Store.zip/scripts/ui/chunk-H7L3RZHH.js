import{p as M}from"./chunk-X34OZWQX.js";import{d as g,e as m,f as l,i as C}from"./chunk-N5VT2JC5.js";import{U as i,l as c}from"./chunk-RCREB6RR.js";import{a as p}from"./chunk-PNQHXYIW.js";import{b as o,c as s,e as f}from"./chunk-OPUCCACO.js";import{f as y,o as n,q as t}from"./chunk-6567QU4Q.js";n();t();var a=y(p());C();M();n();t();i();i();f();var d=()=>{};async function z(e){return s().getCustomCoinInfo(e)}async function G(e){await s().addCustomCoins(e)}function J(e){return o().addCrypto(e,d)}function Q(e){return o().removeServerCoins(e,d)}function V(){return async e=>{e(g()),a.default.debug("background.setCurrentCurrency");let r;try{r={}}catch(u){a.default.error(u.stack),e(l(u.message));return}finally{e(m())}e({type:c,value:{currentCurrency:r.currentCurrency,conversionRate:r.conversionRate,conversionDate:r.conversionDate}})}}export{z as a,G as b,J as c,Q as d,V as e};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-H7L3RZHH.js.map
