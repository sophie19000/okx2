import{o as n,q as o}from"./chunk-6567QU4Q.js";n();o();

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-ILVYWYGM.js.map
