import{g as a}from"./chunk-7OSPB4XE.js";import{$ as s}from"./chunk-HEHV4WEB.js";import{b as d}from"./chunk-VND3RKVB.js";import{f as t,o as e,q as r}from"./chunk-6567QU4Q.js";e();r();var l=t(d());var m=({title:o})=>{let i=a({light:"/static/images/logo-light.svg",dark:"/static/images/logo-dark.svg"});return l.default.createElement("div",{className:"okx-wallet-loader"},l.default.createElement("img",{className:"okx-wallet-loader__logo",src:i,alt:""}),o&&l.default.createElement("div",{className:"okx-wallet-loader__title"},o))},k=(0,l.memo)(()=>{let o=a({light:"./static/images/dex-logo-light.png",dark:"./static/images/dex-logo-dark.png"});return l.default.createElement("div",{className:"okx-wallet-loader dex-loader-wrapper"},l.default.createElement("img",{className:"okx-wallet-loader__logo",src:o,alt:""}),l.default.createElement("div",{className:"okx-wallet-loader__spinner"},l.default.createElement(s.Circle,null)))}),n=(0,l.memo)(m);export{k as a,n as b};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-S46KMKRO.js.map
