import{a as k}from"./chunk-67WI3AGG.js";import{h as I}from"./chunk-YVRQH7O3.js";import{o as F}from"./chunk-GT42CPWV.js";import{e as N}from"./chunk-YNJWLJZS.js";import{$c as g,Ad as E,Vb as n,Xc as a,Zc as T,cd as h,kd as y}from"./chunk-BY6GMUSF.js";import{H as d,ja as A,la as u,ra as S}from"./chunk-2A3K6ORU.js";import{f as x,o as t,q as o}from"./chunk-6567QU4Q.js";t();o();var L=x(F());S();g();t();o();E();g();var q=(i="")=>{let e=T(i);return[h,y,n].includes(e)||N(e)},p=q;var X=i=>{let e=I(i),m=k();return(0,L.useMemoizedFn)(l=>{if(d(e))return[];let{addressType:w={},account:f={}}=e,B=Object.entries(f).filter(([r])=>p(r)).map(([,r])=>r),c=[];a.forEach(()=>{let r=w?.[n]?.map(b=>b.address)||[];c.push(...r)});let O=u(A(B,c));if(d(l))return O;let s=m?.find(r=>r.chainId===Number(l))?.localType;if(!s||!p(s))return[];if(a.indexOf(s)>-1)return u(c);let C=f[s];return C?[C]:[]})};export{X as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-NROQ774C.js.map
