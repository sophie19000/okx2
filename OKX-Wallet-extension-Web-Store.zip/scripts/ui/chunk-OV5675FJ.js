import{a as s}from"./chunk-XFQNCU35.js";import{b as a}from"./chunk-VND3RKVB.js";import{f as u,o as i,q as o}from"./chunk-6567QU4Q.js";i();o();var p=u(a());var l=n=>{let{currentNetworkUniqueId:e}=s();return(0,p.useMemo)(()=>{let t=n||[];return e!==""?t.filter(r=>r?.type===1?!Array.isArray(r?.chainList)||Array.isArray(r?.chainList)&&!r?.chainList?.length?!1:r?.chainList?.findIndex(c=>Number(c?.chainIndex)===Number(e))!==-1:+r?.chainId==+e):t},[n,e])};export{l as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-OV5675FJ.js.map
