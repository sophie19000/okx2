import{a as i,d as m}from"./chunk-QNDAODI3.js";import{c as p}from"./chunk-JPGFEMXH.js";import{f as o,g as s,h as g,i as f}from"./chunk-N5VT2JC5.js";import{c as t,e as l}from"./chunk-OPUCCACO.js";import{o as a,q as n}from"./chunk-6567QU4Q.js";a();n();f();l();function O(){return async e=>{try{await t().completeOnboarding(),e(s())}catch(r){throw e(o(r.message)),r}}}function D(){return async e=>{try{await t().resetOnboarding(),await t().clearDappData(),await m(i.moonCatData),e(g()),e(p(!1))}catch(r){throw e(o(r.message)),r}}}export{O as a,D as b};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-NCAAEPJY.js.map
