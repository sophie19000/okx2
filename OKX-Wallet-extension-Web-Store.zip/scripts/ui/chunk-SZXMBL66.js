import{ca as n}from"./chunk-CKMW3O5Z.js";import{o,q as t}from"./chunk-6567QU4Q.js";o();t();var u=(e,r)=>{let{useCoin:s}=n.hooks;return s(e,r)};export{u as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-SZXMBL66.js.map
