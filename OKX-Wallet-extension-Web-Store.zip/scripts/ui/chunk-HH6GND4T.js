import{G as y,n as t}from"./chunk-UO3B6UBI.js";import{o as r,q as n}from"./chunk-6567QU4Q.js";r();n();y();var D=90;function m(e=t.subtract(D,"d")){let s=t.set({y:e.getFullYear(),M:e.getMonth()+1,d:e.getDate(),h:0,m:0,s:0,ms:0}),a=new Date,o=t.set({y:a.getFullYear(),M:a.getMonth()+1,d:a.getDate(),h:0,m:0,s:0,ms:0});return{stringDates:[t.format(s,"yyyy-MM-dd"),t.format(o,"yyyy-MM-dd")],dates:[s,o]}}export{m as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-HH6GND4T.js.map
