import{e as n}from"./chunk-GXOGUYTN.js";import{u as s}from"./chunk-IA3CMIZI.js";import{rb as t}from"./chunk-2VNSL6BU.js";import{o,q as i}from"./chunk-6567QU4Q.js";o();i();var A=r=>s(r)&&n(r,t.BTC_MAINNET),p=r=>n(r,t.TRON_MAINNET),C=r=>n(r,t.SUI_MAINNET),c=r=>n(r,t.STACKS_MAINNET),h=r=>n(r,t.STARKNET_MAINNET),u=r=>n(r,t.SOLANA_MAINNET),E=r=>n(r,t.APTOS_MAINNET),I=r=>n(r,t.TON_MAINNET);export{A as a,p as b,C as c,c as d,h as e,u as f,E as g,I as h};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-53BD3ML4.js.map
