import{a as T,k as E}from"./chunk-YVRQH7O3.js";import{q as l,r as m}from"./chunk-ZDCNELFZ.js";import{a as L}from"./chunk-RKBUK4AS.js";import{c as p,d,g as c}from"./chunk-QNHAWRKC.js";import{e as i}from"./chunk-D7JIIDCW.js";import{b as y}from"./chunk-VND3RKVB.js";import{f as o,o as a,q as s}from"./chunk-6567QU4Q.js";a();s();var f=o(T()),u=o(L());var C=o(y());var _=()=>{let e=(0,u.useHistory)(),t=E();return(0,C.useCallback)(async r=>{let g=await c.hasConnectedLedger(),{walletName:h}=t(r),n=`${m}?${f.default.stringify({type:i.addChain,walletId:r})}`;g?e.push(n):d.openModal(p.hardWareNotConnected,{walletName:h,onButtonClick:()=>{globalThis.platform.openExtensionInBrowser(l)},onExtButtonClick:()=>{globalThis.platform.openExtensionInBrowser(`${n}&hideBack=1`)}})},[e,t])};export{_ as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-MYRWFDGN.js.map
