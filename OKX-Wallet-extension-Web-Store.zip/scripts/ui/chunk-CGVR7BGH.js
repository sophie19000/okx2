import{a as r}from"./chunk-NYRMYQVP.js";import{ic as D}from"./chunk-SJNNRA35.js";import{f as e,h as n}from"./chunk-Z4N45TGK.js";import{f as s,o,q as a}from"./chunk-6567QU4Q.js";o();a();var i=s(D());var p=m=>{let t=((0,i.useSelector)(r)||{})[m?.origin]||{};return{host:t.host||"",name:t.name||n,icon:t.icon||e}},d=p;export{d as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-CGVR7BGH.js.map
