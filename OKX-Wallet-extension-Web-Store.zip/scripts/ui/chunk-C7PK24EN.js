import{b as f}from"./chunk-VND3RKVB.js";import{f as e,o,q as t}from"./chunk-6567QU4Q.js";o();t();var i=e(f());o();t();var l={globalNotifationUrl:"_globalNotifationUrl_6rjyc_1",globalNotifationUrlText:"_globalNotifationUrlText_6rjyc_6"};function m({url:r,urlText:n,history:a}){return i.default.createElement("div",{className:l.globalNotifationUrl,onClick:()=>{if(a){a.push(r);return}globalThis.platform.openTab({url:r})}},i.default.createElement("span",{className:l.globalNotifationUrlText},n))}var d=m;export{d as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-C7PK24EN.js.map
