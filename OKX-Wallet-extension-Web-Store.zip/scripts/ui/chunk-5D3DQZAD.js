import{a as n}from"./chunk-WN342F2F.js";import{a as m}from"./chunk-VGLNT24Y.js";import{e as s}from"./chunk-NYRMYQVP.js";import{b as c}from"./chunk-ZSBIVYRR.js";import{ic as d}from"./chunk-SJNNRA35.js";import{G as k,x as l}from"./chunk-UO3B6UBI.js";import{b as g}from"./chunk-VND3RKVB.js";import{f as r,o as a,q as i}from"./chunk-6567QU4Q.js";a();i();var p=r(g()),u=r(d());k();var B=()=>{let t=(0,u.useSelector)(s),{isNotBackupWallet:o}=m(),f=n(),{loadingMoonCatData:e}=c();(0,p.useEffect)(()=>{t&&o&&!e&&f({text:l("wallet_dapp_conncetion_alert_backup_wallet")},t)},[o,t,e])},h=B;export{h as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-5D3DQZAD.js.map
