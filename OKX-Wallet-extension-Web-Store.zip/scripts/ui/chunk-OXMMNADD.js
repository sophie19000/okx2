import{a as f}from"./chunk-DAODLUKI.js";import{d as c}from"./chunk-YWPL3Q2Y.js";import{b as e}from"./chunk-JFIRLGIN.js";import{r as t}from"./chunk-VJV3G3PD.js";import{e as n}from"./chunk-Z4N45TGK.js";import{c as r}from"./chunk-OEZTX2LV.js";import{G as I,x as a}from"./chunk-UO3B6UBI.js";import{b as u}from"./chunk-VND3RKVB.js";import{f as s,o as m,q as i}from"./chunk-6567QU4Q.js";m();i();var o=s(u());I();var y=({coinId:l})=>{let p=c(l);return o.default.createElement(f,{title:a("wallet_dapp_conncetion_subtitle_network")},o.default.createElement(r.Space,{align:r.ALIGN.center,space:4},o.default.createElement(e,{src:p?.image,size:e.SIZE.xs,defaultIcon:n}),o.default.createElement(t.Text,{size:t.SIZE.sm},p?.chainName)))},h=y;export{h as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-OXMMNADD.js.map
