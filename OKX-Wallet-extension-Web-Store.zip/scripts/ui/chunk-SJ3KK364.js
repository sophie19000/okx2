import{a as s}from"./chunk-FX3UPSID.js";import{d as i}from"./chunk-EHMPLH5F.js";import{ic as c}from"./chunk-SJNNRA35.js";import{f as l,o,q as n}from"./chunk-6567QU4Q.js";o();n();var e=l(c());var f=()=>{let{currentNetworkUniqueId:t}=(0,e.useSelector)(i),r=(0,e.useSelector)(s);return r.length===1&&t===""?String(r[0].chainId):t};export{f as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-SJ3KK364.js.map
