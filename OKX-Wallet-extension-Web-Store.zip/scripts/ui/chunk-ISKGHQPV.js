import{a as s,b as o}from"./chunk-5GGA24NK.js";import{b as l}from"./chunk-VND3RKVB.js";import{f as M,o as a,q as t}from"./chunk-6567QU4Q.js";a();t();var m=M(l());var f=()=>{let i=s().media,[c,n]=(0,m.useState)({isSm:i==="sm",isMd:i==="md",isLg:i==="lg",isXl:i==="xl",isMobile:i==="sm"||i==="md",media:i});return(0,m.useEffect)(()=>{let d=new o;return d.watch(e=>{n({isSm:e.media==="sm",isMd:e.media==="md",isLg:e.media==="lg",isXl:e.media==="xl",media:e.media,isMobile:e.media==="sm"||e.media==="md"})},{runNow:!0}),()=>{d.destroy()}},[]),c};export{f as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-ISKGHQPV.js.map
