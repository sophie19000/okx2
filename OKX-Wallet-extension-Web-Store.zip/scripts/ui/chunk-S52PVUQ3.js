import{o as u}from"./chunk-GT42CPWV.js";import{b as f}from"./chunk-VND3RKVB.js";import{f as o,o as a,q as s}from"./chunk-6567QU4Q.js";a();s();var i=o(f()),n=o(u()),c=t=>{let[r,e]=(0,i.useState)(!1),l=(0,n.useMemoizedFn)(async()=>{try{e(!0),await t()}finally{e(!1)}});return{loading:r,onClick:t&&l}},m=c;export{m as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-S52PVUQ3.js.map
