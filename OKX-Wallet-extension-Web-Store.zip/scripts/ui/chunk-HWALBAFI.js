import{Aa as p,Ga as r,Ha as E,lb as T,ub as d,za as f}from"./chunk-BY6GMUSF.js";import{H as m,o}from"./chunk-CB5UL2JJ.js";import{o as i,q as s}from"./chunk-6567QU4Q.js";i();s();E();p();d();var g=async({confirmText:a,callback:e})=>{try{await T(f.getDisabedCreateAndImport),e&&e()}catch(t){t.status===r.STATUS_CODE.ERR_NETWORK||t.status===r.STATUS_CODE.ERR_TIMEOUT?e&&e():t.code=="900003"?o.tip({infoType:o.Tip.INFO_TYPE.default,title:t.msg,confirmText:a,onConfirm:n=>{n.destroy()}}):m.error(`System error, ${t.status} ${t.msg}`)}},R=g;export{R as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-HWALBAFI.js.map
