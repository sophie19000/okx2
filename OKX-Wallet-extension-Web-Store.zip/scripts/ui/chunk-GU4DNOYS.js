import{o as r,q as e}from"./chunk-6567QU4Q.js";r();e();

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-GU4DNOYS.js.map
