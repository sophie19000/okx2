import{ic as d}from"./chunk-SJNNRA35.js";import{j as i,p as n}from"./chunk-X34OZWQX.js";import{c as s,e as f}from"./chunk-OPUCCACO.js";import{D as r}from"./chunk-ZBTXKGF6.js";import{b as c}from"./chunk-VND3RKVB.js";import{f as e,o as a,q as o}from"./chunk-6567QU4Q.js";a();o();var p=e(c()),m=e(d());f();n();var l=()=>{let t=(0,m.useDispatch)();return(0,p.useCallback)(async({id:u})=>{await s().finishRequest({id:u,type:r.REJECTED}),await i(t)},[t])},k=l;export{k as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-P4W6YSHL.js.map
