import{e as g}from"./chunk-MDUZG7S3.js";import{c as A,i as T}from"./chunk-3P7JMI3F.js";import{g as I}from"./chunk-YVRQH7O3.js";import{o as D}from"./chunk-GT42CPWV.js";import{$c as L,Ed as y,Id as S,Zc as f}from"./chunk-BY6GMUSF.js";import{o as l,ra as b}from"./chunk-2A3K6ORU.js";import{f as w,o as d,q as m}from"./chunk-6567QU4Q.js";d();m();var i=w(D());b();L();S();var v=(r,C)=>{let h=I(),s=C??h,u=g(s),a=(0,i.useCreation)(()=>u.find(n=>n.coinId===r?.coinId),[u,r?.coinId])?.childrenCoin??[],o=A(r?.localType,s),c=T(r?.localType,s);return(0,i.useCreation)(()=>{if(!r||!Array.isArray(a)||!Array.isArray(o)||!o.length)return[];let n=a.filter(e=>e.coinId===+r?.coinId).map(e=>({...e})),p=[],t=l(n[0]||r),B=n.map(e=>c[e.addressType]);return o.forEach(({address:e,addressType:W})=>{B.includes(e)||(t.address=e,t.userAddress=e,t.addressType=y[f(r?.localType)]?.[W],t.coinAmount=0,t.coinAmountInt=0,t.currencyAmount=0,t.currencyAmountUSD=0,p.push(l(t)))}),n.concat(p).filter(e=>Boolean(c[e.addressType]))},[r,a,o,c])};export{v as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-EQ3DHJMO.js.map
