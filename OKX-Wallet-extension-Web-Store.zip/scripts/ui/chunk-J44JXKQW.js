import{d as c}from"./chunk-COE5JBMZ.js";import{k as o,l as a}from"./chunk-PNQHXYIW.js";import{o as t,q as r}from"./chunk-6567QU4Q.js";t();r();a();var i=c("Chain"),s={blockNumber:0},n=o({name:i,initialState:s,reducers:{setBlockNumber:(e,{payload:m})=>{e.blockNumber=m}}}),k=e=>e[n.name].blockNumber;var{actions:l,reducer:u}=n,{setBlockNumber:x}=l;var d=u;export{i as a,k as b,x as c,d};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-J44JXKQW.js.map
