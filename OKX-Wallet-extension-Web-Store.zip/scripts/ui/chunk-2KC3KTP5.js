import{f as t}from"./chunk-JHAESO4C.js";import{ic as a}from"./chunk-SJNNRA35.js";import{f as o,o as e,q as r}from"./chunk-6567QU4Q.js";e();r();var n=o(a());function c(){return(0,n.useSelector)(t)}export{c as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-2KC3KTP5.js.map
