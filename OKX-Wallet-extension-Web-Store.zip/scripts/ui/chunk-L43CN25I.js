import{o as O,q as _}from"./chunk-6567QU4Q.js";O();_();var N={COMMON_ERROR:1,BALANCE_NOT_ENOUGH:100041,PURE_UTXO_NOT_ENOUGH:100043,TX_NOT_FOUND:400004,TX_ALREADY_CONFIRMED:400005};export{N as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-L43CN25I.js.map
