import{Ca as i}from"./chunk-SJNNRA35.js";import{p as s,q as e}from"./chunk-ZBTXKGF6.js";import{o as n,q as u}from"./chunk-6567QU4Q.js";n();u();var p=async({chainId:c,address:o,contractAddress:m,coinId:S})=>{let E=await i({chainId:c,address:o,contractAddress:m,coinId:S}),{status:r,alertMessage:d,url:R,register:a}=E||{},t={alertMessage:d,url:R,register:a,status:e.PROCESSING};return a||r===s.SUCCESS?(t.status=e.COMPLETED,t):((r===s.NONE||r===s.TIMEOUT||r===s.ERROR)&&(t.status=e.NOT_STARTED),t)};export{p as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-DZSYN6UQ.js.map
