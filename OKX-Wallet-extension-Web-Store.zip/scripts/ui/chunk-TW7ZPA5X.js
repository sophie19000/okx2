import{j as f,p as g}from"./chunk-X34OZWQX.js";import{f as m,i as P}from"./chunk-N5VT2JC5.js";import{b as n,e as c}from"./chunk-OPUCCACO.js";import{o as u,q as p}from"./chunk-6567QU4Q.js";u();p();P();g();c();function d(r,t,i=""){return e=>{n().approvePermissionsRequest(r,t,i,s=>{s&&e(m(s.message))})}}function k(r,t,i){return e=>new Promise((s,a)=>{n().rejectPermissionsRequest(r,t,i,o=>{if(o){e(m(o.message)),a(o);return}f(e).then(s).catch(a)})})}export{d as a,k as b};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-TW7ZPA5X.js.map
