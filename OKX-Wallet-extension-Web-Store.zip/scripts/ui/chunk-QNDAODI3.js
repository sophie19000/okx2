import{F as i,I as g}from"./chunk-BY6GMUSF.js";import{G as c,w as a}from"./chunk-UO3B6UBI.js";import{o,q as n}from"./chunk-6567QU4Q.js";o();n();var p={coinTickers:"coinTickers",catTokensConfig:"catTokensConfig",catSpendsConfig:"catSpendsConfig",keyringController:"KeyringController",moonCatData:"backHistory",chainController:"ChainController",reportedCoins:"reportedCoins"};o();n();c();g();var r;async function s(){return r||(r=await a.chrome.init({project:i})),r}async function S(t,e){return(await s()).set(t,e)}async function k(t){return(await s()).get(t)}async function T(t){return(await s()).remove(t)}export{p as a,S as b,k as c,T as d};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-QNDAODI3.js.map
