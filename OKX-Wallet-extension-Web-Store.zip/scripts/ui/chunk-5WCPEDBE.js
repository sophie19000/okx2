import{c as s,o as a,q as c}from"./chunk-6567QU4Q.js";var v=s((m,y)=>{a();c();y.exports=h;function h(e,r){if(e&&r)return h(e)(r);if(typeof e!="function")throw new TypeError("need wrapper function");return Object.keys(e).forEach(function(t){n[t]=e[t]}),n;function n(){for(var t=new Array(arguments.length),o=0;o<t.length;o++)t[o]=arguments[o];var u=e.apply(this,t),l=t[t.length-1];return typeof u=="function"&&u!==l&&Object.keys(l).forEach(function(f){u[f]=l[f]}),u}}});var b=s((O,p)=>{a();c();var d=v();p.exports=d(i);p.exports.strict=d(w);i.proto=i(function(){Object.defineProperty(Function.prototype,"once",{value:function(){return i(this)},configurable:!0}),Object.defineProperty(Function.prototype,"onceStrict",{value:function(){return w(this)},configurable:!0})});function i(e){var r=function(){return r.called?r.value:(r.called=!0,r.value=e.apply(this,arguments))};return r.called=!1,r}function w(e){var r=function(){if(r.called)throw new Error(r.onceError);return r.called=!0,r.value=e.apply(this,arguments)},n=e.name||"Function wrapped with `once`";return r.onceError=n+" shouldn't be called more than once",r.called=!1,r}});export{v as a,b};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-5WCPEDBE.js.map
