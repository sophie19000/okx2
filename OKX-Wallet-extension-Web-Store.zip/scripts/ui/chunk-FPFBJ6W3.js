import{g as a,h as o}from"./chunk-YVRQH7O3.js";import{b as d}from"./chunk-VND3RKVB.js";import{f as s,o as n,q as r}from"./chunk-6567QU4Q.js";n();r();var y=s(d());var u={"MNEMONIC WALLET":"seed_phrase","PRIVATE KEY WALLET":"private_key","MPC WALLET":"mpc","HARDWARE WALLET":"hardware"},l=e=>{let p=a(),i=o(p),t=u[i?.keyringIdentityType];return(0,y.useCallback)(c=>{e({...c,wallet_type:t})},[e,t])},A=l;export{A as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-FPFBJ6W3.js.map
