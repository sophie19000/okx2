import{Aa as m,lb as o,ub as u,za as e}from"./chunk-BY6GMUSF.js";import{b as i}from"./chunk-VND3RKVB.js";import{f as n,o as t,q as r}from"./chunk-6567QU4Q.js";t();r();m();u();var p=n(i()),x="dexSupportChain",E=()=>({fetch:(0,p.useCallback)(()=>o(e.getDexSupportChain),[])});export{x as a,E as b};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-V4IK5ZRR.js.map
