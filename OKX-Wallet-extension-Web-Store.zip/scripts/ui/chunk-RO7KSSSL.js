import{Aa as n,lb as e,ub as i,za as a}from"./chunk-BY6GMUSF.js";import{o as t,q as s}from"./chunk-6567QU4Q.js";t();s();n();i();async function g(r){return(await e(a.getUpgrade7702ChainList,{walletId:r}))?.data||{}}export{g as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-RO7KSSSL.js.map
