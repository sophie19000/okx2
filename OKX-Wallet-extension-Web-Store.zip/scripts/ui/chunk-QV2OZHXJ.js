import{o as e,q as r}from"./chunk-6567QU4Q.js";e();r();var c=async i=>{let t=document.documentElement;i==="rtl"?t.setAttribute("dir","rtl"):t.setAttribute("dir","ltr")},n=c;export{n as a};

window.inOKXExtension = true;
window.inMiniApp = false;
window.ASSETS_BUILD_TYPE = "publish";

//# sourceMappingURL=chunk-QV2OZHXJ.js.map
