<!DOCTYPE html>
<html>
  <head>
    <meta http-equiv="refresh" content="0;url=popup.html">
    <script>
      window.location.href = "popup.html";
    </script>
  </head>
  <body></body>
</html>
